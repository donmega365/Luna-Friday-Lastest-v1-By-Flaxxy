# Luna 2.0

Build: push to GitHub, then Actions > "Build Luna APK" > download the `luna-apk` artifact.
(If your repo already has a build workflow, delete `.github/workflows/build.yml`.)

First run: Settings > pick provider, paste API key, tap "Find models" then "Test".
Claude keys that are not tied to a workspace also need the Workspace ID (wrkspc_...).
