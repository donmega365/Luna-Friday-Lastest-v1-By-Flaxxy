package com.luna.assistant

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppLog {
    fun add(c: Context, msg: String) {
        try {
            val l = Prefs.getList(c, "log")
            l.add(0, SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + "  " + msg)
            while (l.size > 30) l.removeAt(l.size - 1)
            Prefs.putList(c, "log", l)
        } catch (_: Exception) {
        }
    }

    fun text(c: Context): String {
        val l = Prefs.getList(c, "log")
        return if (l.isEmpty()) "(empty)" else l.joinToString("\n")
    }

    fun clear(c: Context) = Prefs.putList(c, "log", emptyList())
}
