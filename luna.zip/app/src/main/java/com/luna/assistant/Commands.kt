package com.luna.assistant

data class Cmd(val kind: String, val a: String = "", val b: String = "")

object Commands {
    private val openWords = "open|launch|start|kholo|khol|खोलो|खोल|کھولو|کھول"
    private val openSuffix = "kholo|khol do|khol de|khol|open karo|open kar do|chalu karo|chalao|खोलो|खोल दो|کھولو|کھول دو"

    fun parse(t: String): Cmd? {
        val s = t.trim()
        if (s.isEmpty()) return null
        val l = s.lowercase()
        val words = l.split(" ").size

        if (l.startsWith("busy")) {
            return Cmd("busy", if (l.contains("off") || l.contains("band") || l.contains("stop")) "off" else "on")
        }
        if (words <= 6 && (l.contains("torch") || l.contains("flashlight"))) {
            return Cmd("torch", if (l.contains("off") || l.contains("band") || l.contains("बंद")) "off" else "on")
        }
        Regex("^(?:volume|awaz|आवाज़|volume set to)\\s*(up|down|max|full|mute|low|\\d{1,3})$").find(l)
            ?.let { return Cmd("volume", it.groupValues[1]) }
        Regex("^brightness\\s+(\\d{1,3})$").find(l)?.let { return Cmd("brightness", it.groupValues[1]) }
        Regex("^(?:set\\s+)?alarm(?:\\s+(?:for|at))?\\s+(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?$").find(l)?.let { m ->
            var h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = m.groupValues[3]
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            if (h in 0..23 && mi in 0..59) return Cmd("alarm", "$h:$mi")
        }
        Regex("^(?:set\\s+)?timer(?:\\s+(?:for|of))?\\s+(\\d+)\\s*(sec|secs|second|seconds|min|mins|minute|minutes|hour|hours|hr|hrs)?$")
            .find(l)?.let { m ->
                val n = m.groupValues[1].toInt()
                val u = m.groupValues[2]
                val secs = when {
                    u.startsWith("h") -> n * 3600
                    u.startsWith("s") -> n
                    else -> n * 60
                }
                return Cmd("timer", secs.toString())
            }
        if (words <= 5 && l.contains("battery")) return Cmd("battery")
        if (words <= 4 && (l == "time" || l.contains("what time") || l.contains("time kya"))) return Cmd("time")
        Regex("^(?:read|show)\\s+(?:my\\s+)?(?:last\\s+)?(?:sms|message|messages)$").find(l)?.let { return Cmd("readsms") }
        Regex("^(?:send\\s+)?(?:whatsapp|wa)\\s+(?:message|msg|to)\\s+(\\S+)\\s+(.+)$", RegexOption.IGNORE_CASE).find(s)
            ?.let { return Cmd("wamsg", it.groupValues[1], it.groupValues[2]) }
        Regex("^(?:sms|text)\\s+(\\S+)\\s+(.+)$", RegexOption.IGNORE_CASE).find(s)
            ?.let { return Cmd("sms", it.groupValues[1], it.groupValues[2]) }
        Regex("^(wifi|bluetooth|location|display|sound)\\s+settings$").find(l)?.let { return Cmd("settings", it.groupValues[1]) }

        if (words <= 6) {
            Regex("^(?:$openWords)\\s+(.+)$").find(l)?.let { return Cmd("open", it.groupValues[1].trim()) }
            Regex("^(.+?)\\s+(?:$openSuffix)$").find(l)?.let { return Cmd("open", it.groupValues[1].trim()) }
            Regex("^(?:call|phone|dial|کال)\\s+(.+)$").find(l)?.let { return Cmd("call", it.groupValues[1].trim()) }
            Regex("^(.+?)\\s+(?:ko|को|کو)\\s+(?:call|phone|कॉल|کال)(?:\\s+\\S+){0,2}$").find(l)
                ?.let { return Cmd("call", it.groupValues[1].trim()) }
        }
        Regex("^(?:navigate|directions|route)\\s+(?:to\\s+)?(.+)$").find(l)?.let { return Cmd("navigate", it.groupValues[1]) }
        Regex("^take me to\\s+(.+)$").find(l)?.let { return Cmd("navigate", it.groupValues[1]) }
        Regex("^(?:youtube|yt|play)\\s+(.+)$").find(l)?.let { return Cmd("youtube", it.groupValues[1]) }
        Regex("^(?:search|google)\\s+(.+)$").find(l)?.let { return Cmd("search", it.groupValues[1]) }
        return null
    }
}
