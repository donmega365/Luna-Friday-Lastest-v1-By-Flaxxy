package com.luna.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

object Langs {
    val list = listOf(
        "English (India)" to "en-US", "English (US)" to "en-US", "English (UK)" to "en-GB",
        "हिन्दी Hindi" to "hi-IN", "اردو Urdu" to "ur-PK", "العربية Arabic" to "ar-SA",
        "বাংলা Bengali" to "bn-IN", "தமிழ் Tamil" to "ta-IN", "తెలుగు Telugu" to "te-IN",
        "मराठी Marathi" to "mr-IN", "ગુજરાતી Gujarati" to "gu-IN", "ਪੰਜਾਬੀ Punjabi" to "pa-IN",
        "Español" to "es-ES", "Français" to "fr-FR", "Deutsch" to "de-DE", "Português" to "pt-BR",
        "Русский" to "ru-RU", "Türkçe" to "tr-TR", "Bahasa Indonesia" to "id-ID",
        "日本語" to "ja-JP", "한국어" to "ko-KR", "中文" to "zh-CN", "Italiano" to "it-IT"
    )
}

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false

    fun init(c: Context, onReady: (() -> Unit)? = null) {
        if (tts != null && ready) {
            onReady?.invoke()
            return
        }
        if (tts != null) return
        tts = TextToSpeech(c.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            if (ready) applyPrefs(c)
            onReady?.invoke()
        }
    }

    fun applyPrefs(c: Context) {
        val t = tts ?: return
        if (!ready) return
        try {
            t.setLanguage(Locale.forLanguageTag(Prefs.get(c, "lang", "en-US")))
            val vn = Prefs.get(c, "voice")
            if (vn.isNotBlank()) {
                t.voices?.firstOrNull { it.name == vn }?.let { t.setVoice(it) }
            }
        } catch (_: Exception) {
        }
    }

    fun voicesFor(c: Context): List<Voice> {
        val t = tts ?: return emptyList()
        if (!ready) return emptyList()
        val lang = Locale.forLanguageTag(Prefs.get(c, "lang", "en-US")).language
        return try {
            t.voices?.filter { it.locale.language == lang }?.sortedBy { it.name } ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    // Picks a voice language from the script of the text (Hindi, Urdu, Bengali, ...), else null.
    private fun scriptTag(c: Context, text: String): String? {
        for (ch in text) {
            val cp = ch.code
            if (cp < 0x0400) continue
            return when (cp) {
                in 0x0900..0x097F -> "hi-IN"
                in 0x0600..0x06FF -> if (Prefs.get(c, "lang", "en-US").startsWith("ar")) "ar-SA" else "ur-PK"
                in 0x0980..0x09FF -> "bn-IN"
                in 0x0A00..0x0A7F -> "pa-IN"
                in 0x0A80..0x0AFF -> "gu-IN"
                in 0x0B80..0x0BFF -> "ta-IN"
                in 0x0C00..0x0C7F -> "te-IN"
                in 0x0400..0x04FF -> "ru-RU"
                in 0x3040..0x30FF -> "ja-JP"
                in 0xAC00..0xD7AF -> "ko-KR"
                in 0x4E00..0x9FFF -> "zh-CN"
                else -> continue
            }
        }
        return null
    }

    fun speak(c: Context, text: String) {
        init(c) {
            applyPrefs(c)
            val tag = scriptTag(c, text)
            if (tag != null) {
                try {
                    tts?.setLanguage(Locale.forLanguageTag(tag))
                } catch (_: Exception) {
                }
            }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "luna")
        }
    }
}
