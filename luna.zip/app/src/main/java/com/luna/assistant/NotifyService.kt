package com.luna.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telephony.TelephonyManager

class NotifyService : NotificationListenerService() {
    private val last = HashMap<String, Long>()
    private val warned = HashSet<String>()
    private var callRx: CallReceiver? = null

    override fun onListenerConnected() {
        super.onListenerConnected()
        AppLog.add(this, "Notification listener connected")
        if (callRx == null) {
            val rx = CallReceiver()
            val f = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
            try {
                if (Build.VERSION.SDK_INT >= 33) {
                    registerReceiver(rx, f, Context.RECEIVER_EXPORTED)
                } else {
                    registerReceiver(rx, f)
                }
                callRx = rx
            } catch (_: Exception) {
            }
        }
    }

    override fun onListenerDisconnected() {
        try {
            callRx?.let { unregisterReceiver(it) }
        } catch (_: Exception) {
        }
        callRx = null
        AppLog.add(this, "Notification listener disconnected")
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Exception) {
            AppLog.add(this, "Error: ${e.message}")
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        val ex = n.extras ?: return
        val isTest = ex.getBoolean("luna_test", false)
        if (sbn.packageName == packageName && !isTest) return
        if (!isTest && (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val title = (ex.getCharSequence(Notification.EXTRA_TITLE)
            ?: ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE))?.toString() ?: return
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""

        val acts = ArrayList<Notification.Action>()
        n.actions?.let { acts.addAll(it) }
        acts.addAll(Notification.WearableExtender(n).actions)
        val replyAct = acts.firstOrNull { it.remoteInputs?.isNotEmpty() == true }

        val isMsg = isTest || replyAct != null || n.category == Notification.CATEGORY_MESSAGE ||
            n.category == Notification.CATEGORY_EMAIL
        if (!isMsg) return

        val scam = Scam.isScam(text)
        if (scam && !isTest && Prefs.getBool(this, "scam_guard", true)) {
            if (warned.size > 200) warned.clear()
            if (warned.add(sbn.key)) {
                Notifier.alert(this, "⚠ Scam alert", "Message from \"$title\" looks like a scam. Don't open links, APKs or share OTPs.")
            }
        }
        val busy = Prefs.getBool(this, "busy")
        if (!busy && !isTest) return
        if (!busy && isTest) AppLog.add(this, "TEST note: Busy mode is OFF, so a real message would be ignored")

        val friends = Prefs.getList(this, "busy_friends")
        val match = friends.firstOrNull { title.contains(it, true) }
        if (match == null) {
            AppLog.add(this, "Ignored message from '$title' (not in your friends list)")
            return
        }
        if (!isTest && ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)) {
            AppLog.add(this, "Skipped '$title' (group chat)")
            return
        }
        if (scam && !isTest) {
            AppLog.add(this, "Skipped '$title' (looks like a scam)")
            return
        }
        val now = System.currentTimeMillis()
        if (!isTest && now - (last[match] ?: 0L) < 10 * 60 * 1000L) {
            AppLog.add(this, "Already replied to '$match' in the last 10 minutes")
            return
        }
        val msg = Prefs.get(this, "busy_msg", Defaults.MSG)

        if (replyAct == null) {
            val num = Contacts.numberFor(this, match)
            if (num != null && sbn.packageName.contains("whatsapp") && WaSender.accessibilityOn(this)) {
                last[match] = now
                AppLog.add(this, "No Reply button from '$title', replying through the chat screen instead")
                WaSender.send(this, num, msg)
            } else {
                AppLog.add(this, "Message from '$title' (${sbn.packageName}) has no Reply button, can't auto-reply")
            }
            return
        }

        try {
            val ris = replyAct.remoteInputs
            val intent = Intent()
            val bundle = Bundle()
            for (r in ris) bundle.putCharSequence(r.resultKey, msg)
            RemoteInput.addResultsToIntent(ris, intent, bundle)
            replyAct.actionIntent.send(this, 0, intent)
            last[match] = now
            AppLog.add(this, "Auto-replied to '$match' via ${sbn.packageName}")
        } catch (e: Exception) {
            AppLog.add(this, "Auto-reply failed for '$match': ${e.message}")
        }
    }
}
