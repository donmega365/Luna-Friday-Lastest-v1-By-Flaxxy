package com.luna.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.telephony.TelephonyManager

object WaSender {
    class Pending(val text: String, val expires: Long)

    @Volatile
    var pending: Pending? = null

    fun accessibilityOn(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(c.packageName + "/") && s.contains("WaAccessService")
    }

    private fun installedPkg(c: Context): String? {
        val pm = c.packageManager
        val installed = listOf("com.whatsapp.w4b", "com.whatsapp").filter {
            try {
                pm.getPackageInfo(it, 0)
                true
            } catch (_: Exception) {
                false
            }
        }
        val pref = Prefs.get(c, "wa_pkg")
        return if (pref in installed) pref else installed.firstOrNull()
    }

    private val dial = mapOf(
        "in" to "91", "pk" to "92", "bd" to "880", "ae" to "971", "sa" to "966", "us" to "1",
        "ca" to "1", "gb" to "44", "af" to "93", "np" to "977", "lk" to "94", "om" to "968", "qa" to "974", "kw" to "965"
    )

    // wa.me needs full international digits
    fun normalize(c: Context, number: String): String {
        val raw = number.trim()
        var d = raw.filter { it.isDigit() }
        if (raw.startsWith("+")) return d
        if (d.startsWith("00")) return d.drop(2)
        var cc = Prefs.get(c, "cc").filter { it.isDigit() }
        if (cc.isEmpty()) {
            val iso = try {
                c.getSystemService(TelephonyManager::class.java).simCountryIso ?: ""
            } catch (_: Exception) {
                ""
            }
            cc = dial[iso.lowercase()] ?: ""
        }
        if (cc.isEmpty()) return d
        if (d.startsWith("0")) d = d.drop(1)
        return if (d.startsWith(cc) && d.length > 10) d else cc + d
    }

    // Opens the chat with the text filled in; the accessibility service then presses Send.
    fun send(c: Context, number: String, text: String): Boolean {
        val pkg = installedPkg(c) ?: return false
        val digits = normalize(c, number)
        if (digits.isEmpty()) return false
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(text)))
        i.setPackage(pkg)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (accessibilityOn(c)) pending = Pending(text, System.currentTimeMillis() + 25000L)
        return try {
            c.startActivity(i)
            AppLog.add(c, "Opened WhatsApp chat ($pkg) for +$digits" + if (pending != null) ", waiting to press Send" else " (auto-send is OFF, tap Send yourself)")
            true
        } catch (e: Exception) {
            AppLog.add(c, "Could not open WhatsApp: ${e.message} (allow 'Display over other apps')")
            false
        }
    }
}
