package com.luna.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    class P(val id: String, val label: String, val url: String, val model: String, val type: String)

    val providers = listOf(
        P("claude", "Claude (Anthropic)", "https://api.anthropic.com/v1/messages", "claude-sonnet-5-5", "claude"),
        P("openai", "ChatGPT (OpenAI)", "https://api.openai.com/v1/chat/completions", "gpt-4o-mini", "openai"),
        P("gemini", "Gemini (Google)", "https://generativelanguage.googleapis.com/v1beta/models/", "gemini-flash-latest", "gemini"),
        P("groq", "Groq", "https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile", "openai"),
        P("openrouter", "OpenRouter (sab models)", "https://openrouter.ai/api/v1/chat/completions", "openai/gpt-4o-mini", "openai"),
        P("deepseek", "DeepSeek", "https://api.deepseek.com/chat/completions", "deepseek-chat", "openai"),
        P("custom", "Custom (OpenAI-compatible URL)", "", "", "openai")
    )

    fun find(id: String): P = providers.firstOrNull { it.id == id } ?: providers[0]

    fun chat(c: Context, history: List<Pair<String, String>>, system: String): String {
        val p = find(Prefs.get(c, "provider", "claude"))
        val key = Prefs.get(c, "key_" + p.id)
        if (key.isBlank()) return "API key nahi hai. Settings me ${p.label} ki key daalo."
        val model = Prefs.get(c, "model_" + p.id).ifBlank { p.model }
        val url = if (p.id == "custom") Prefs.get(c, "custom_url") else p.url
        if (url.isBlank()) return "Custom URL Settings me daalo."
        return try {
            when (p.type) {
                "claude" -> {
                    val msgs = JSONArray()
                    history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
                    val body = JSONObject().put("model", model).put("max_tokens", 1000)
                        .put("system", system).put("messages", msgs)
                    val r = JSONObject(
                        post(url, claudeHeaders(c, key), body.toString())
                    )
                    r.getJSONArray("content").getJSONObject(0).getString("text")
                }
                "gemini" -> {
                    val contents = JSONArray()
                    history.forEach {
                        val role = if (it.first == "assistant") "model" else "user"
                        contents.put(
                            JSONObject().put("role", role)
                                .put("parts", JSONArray().put(JSONObject().put("text", it.second)))
                        )
                    }
                    val body = JSONObject().put("contents", contents).put(
                        "system_instruction",
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                    )
                    val r = JSONObject(post(url + model + ":generateContent?key=" + key, emptyMap(), body.toString()))
                    r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                        .getJSONArray("parts").getJSONObject(0).getString("text")
                }
                else -> {
                    val msgs = JSONArray()
                    msgs.put(JSONObject().put("role", "system").put("content", system))
                    history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
                    val body = JSONObject().put("model", model).put("messages", msgs)
                    val r = JSONObject(post(url, mapOf("Authorization" to "Bearer $key"), body.toString()))
                    r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                }
            }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    private fun claudeHeaders(c: Context, key: String): Map<String, String> {
        val h = mutableMapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")
        val ws = Prefs.get(c, "ws_claude").trim()
        if (ws.isNotEmpty()) h["anthropic-workspace-id"] = ws
        return h
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 15000
        con.readTimeout = 60000
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> con.setRequestProperty(k, v) }
        con.outputStream.use { it.write(body.toByteArray()) }
        val code = con.responseCode
        val stream = if (code in 200..299) con.inputStream else con.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP $code: ${txt.take(400)}")
        return txt
    }
}
