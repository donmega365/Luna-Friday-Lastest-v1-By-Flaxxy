package com.luna.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle

class TestReplyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val r = RemoteInput.getResultsFromIntent(i)
        val t = r?.getCharSequence("luna_reply")?.toString()
        AppLog.add(c, if (t != null) "✅ TEST PASSED: auto-reply was delivered: \"$t\"" else "❌ TEST: reply button fired but had no text")
    }
}

// Posts a fake message notification from your first friend so you can check the whole
// auto-reply chain without needing a real WhatsApp message.
object SelfTest {
    fun run(c: Context) {
        val friends = Prefs.getList(c, "busy_friends")
        if (friends.isEmpty()) {
            AppLog.add(c, "TEST: add at least one friend name in the Busy tab and Save first")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            AppLog.add(c, "TEST: allow the Notifications permission first (Access tab)")
            return
        }
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("luna_test", "Luna self-test", NotificationManager.IMPORTANCE_DEFAULT))
        val ri = RemoteInput.Builder("luna_reply").setLabel("Reply").build()
        val pi = PendingIntent.getBroadcast(
            c, 7, Intent(c, TestReplyReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        val act = Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_send), "Reply", pi)
            .addRemoteInput(ri).build()
        val extra = Bundle()
        extra.putBoolean("luna_test", true)
        val n = Notification.Builder(c, "luna_test")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(friends[0])
            .setContentText("Test message")
            .setCategory(Notification.CATEGORY_MESSAGE)
            .addAction(act)
            .addExtras(extra)
            .setAutoCancel(true)
            .build()
        nm.notify(4242, n)
        AppLog.add(c, "TEST: fake message from '${friends[0]}' posted. If nothing follows in ~5 seconds, notification access is OFF or the service was killed.")
    }
}
