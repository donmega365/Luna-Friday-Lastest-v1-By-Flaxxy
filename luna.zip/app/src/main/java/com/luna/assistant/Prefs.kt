package com.luna.assistant

import android.content.Context
import org.json.JSONArray

object Defaults {
    const val MSG = "Main abhi bahar hu, 5-10 min me wapas aata hu. Thodi der me baat karta hu 🙂"
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("luna", Context.MODE_PRIVATE)

    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun getBool(c: Context, k: String, d: Boolean = false): Boolean = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }

    fun getList(c: Context, k: String): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(get(c, k, "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (_: Exception) {
        }
        return out
    }

    fun putList(c: Context, k: String, v: List<String>) {
        put(c, k, JSONArray(v).toString())
    }
}
