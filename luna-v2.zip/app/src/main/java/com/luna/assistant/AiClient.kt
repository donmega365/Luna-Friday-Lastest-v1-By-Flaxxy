package com.luna.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object AiClient {
    class P(val id: String, val label: String, val url: String, val model: String, val type: String)

    class Reply(val text: String, val ok: Boolean)

    val providers = listOf(
        P("claude", "Claude (Anthropic)", "https://api.anthropic.com/v1/messages", "claude-sonnet-5-5", "claude"),
        P("openai", "ChatGPT (OpenAI)", "https://api.openai.com/v1/chat/completions", "gpt-4o-mini", "openai"),
        P("gemini", "Gemini (Google)", "https://generativelanguage.googleapis.com/v1beta/models/", "gemini-flash-latest", "gemini"),
        P("groq", "Groq", "https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile", "openai"),
        P("openrouter", "OpenRouter (all models)", "https://openrouter.ai/api/v1/chat/completions", "openai/gpt-4o-mini", "openai"),
        P("deepseek", "DeepSeek", "https://api.deepseek.com/chat/completions", "deepseek-chat", "openai"),
        P("custom", "Custom (OpenAI-compatible URL)", "", "", "openai")
    )

    fun find(id: String): P = providers.firstOrNull { it.id == id } ?: providers[0]

    fun current(c: Context): P = find(Prefs.get(c, "provider", "claude"))

    fun modelOf(c: Context, p: P): String = Prefs.get(c, "model_" + p.id).ifBlank { p.model }

    // APIs want the first turn from the user and strictly alternating roles
    private fun clean(history: List<Pair<String, String>>): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        for (h in history) {
            if (h.second.isBlank()) continue
            if (out.isEmpty() && h.first != "user") continue
            if (out.isNotEmpty() && out.last().first == h.first) {
                val last = out.removeAt(out.size - 1)
                out.add(Pair(h.first, last.second + "\n" + h.second))
            } else {
                out.add(h)
            }
        }
        return out
    }

    fun chat(c: Context, history: List<Pair<String, String>>, system: String): Reply {
        val p = current(c)
        val key = Prefs.get(c, "key_" + p.id).trim()
        if (key.isBlank()) return Reply("No API key yet. Open Settings and add your ${p.label} key.", false)
        val url = if (p.id == "custom") Prefs.get(c, "custom_url").trim() else p.url
        if (url.isBlank()) return Reply("Add the custom API URL in Settings first.", false)
        val msgs = clean(history)
        if (msgs.isEmpty()) return Reply("Nothing to send.", false)
        val model = modelOf(c, p)
        return try {
            Reply(call(c, p, url, key, model, msgs, system), true)
        } catch (e: Net.HttpError) {
            // a retired / renamed model: find a working one automatically and remember it
            if (isBadModel(e)) {
                val alt = try {
                    pickModel(c, p, key, model)
                } catch (_: Exception) {
                    null
                }
                if (alt != null && alt != model) {
                    try {
                        val t = call(c, p, url, key, alt, msgs, system)
                        Prefs.put(c, "model_" + p.id, alt)
                        return Reply(t, true)
                    } catch (e2: Exception) {
                        return Reply(friendly(p, e2), false)
                    }
                }
            }
            Reply(friendly(p, e), false)
        } catch (e: Exception) {
            Reply(friendly(p, e), false)
        }
    }

    // plain text for quick tests
    fun ask(c: Context, text: String): String = chat(c, listOf(Pair("user", text)), "Be brief.").text

    private fun isBadModel(e: Net.HttpError): Boolean {
        val b = e.body.lowercase()
        if (e.code == 404) return true
        return e.code == 400 && b.contains("model") && (b.contains("not found") || b.contains("invalid") || b.contains("deprecated") || b.contains("no longer"))
    }

    private fun claudeHeaders(c: Context, key: String): Map<String, String> {
        val h = LinkedHashMap<String, String>()
        h["x-api-key"] = key
        h["anthropic-version"] = "2023-06-01"
        val ws = Prefs.get(c, "ws_claude").trim()
        if (ws.isNotEmpty()) h["anthropic-workspace-id"] = ws
        return h
    }

    private fun call(c: Context, p: P, url: String, key: String, model: String, history: List<Pair<String, String>>, system: String): String {
        when (p.type) {
            "claude" -> {
                val msgs = JSONArray()
                history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
                val body = JSONObject().put("model", model).put("max_tokens", 1024).put("system", system).put("messages", msgs)
                val r = JSONObject(Net.post(url, claudeHeaders(c, key), body.toString()))
                val arr = r.getJSONArray("content")
                val sb = StringBuilder()
                for (i in 0 until arr.length()) {
                    val b = arr.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.optString("text"))
                }
                return sb.toString().trim().ifEmpty { throw Exception("The AI sent an empty reply.") }
            }
            "gemini" -> {
                val contents = JSONArray()
                history.forEach {
                    val role = if (it.first == "assistant") "model" else "user"
                    contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", it.second))))
                }
                val body = JSONObject().put("contents", contents).put(
                    "system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                )
                val r = JSONObject(Net.post(url + model + ":generateContent", mapOf("x-goog-api-key" to key), body.toString()))
                val cands = r.optJSONArray("candidates")
                if (cands == null || cands.length() == 0) {
                    val why = r.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                    throw Exception(if (why.isNotBlank()) "Blocked by the safety filter ($why)." else "The AI sent an empty reply.")
                }
                val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                val sb = StringBuilder()
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val pt = parts.getJSONObject(i)
                        if (!pt.optBoolean("thought", false)) sb.append(pt.optString("text"))
                    }
                }
                return sb.toString().trim().ifEmpty { throw Exception("The AI sent an empty reply.") }
            }
            else -> {
                val msgs = JSONArray()
                msgs.put(JSONObject().put("role", "system").put("content", system))
                history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
                val body = JSONObject().put("model", model).put("messages", msgs)
                val r = JSONObject(Net.post(url, mapOf("Authorization" to "Bearer $key"), body.toString()))
                val m = r.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
                val content = m.opt("content")
                val txt = if (content is JSONArray) {
                    val sb = StringBuilder()
                    for (i in 0 until content.length()) sb.append(content.getJSONObject(i).optString("text"))
                    sb.toString()
                } else {
                    m.optString("content", "")
                }
                return txt.trim().ifEmpty { throw Exception("The AI sent an empty reply.") }
            }
        }
    }

    // ---------- models ----------
    fun listModels(c: Context, p: P, key: String): List<String> {
        val out = ArrayList<String>()
        when (p.type) {
            "claude" -> {
                val r = JSONObject(Net.get("https://api.anthropic.com/v1/models?limit=100", claudeHeaders(c, key)))
                val a = r.getJSONArray("data")
                for (i in 0 until a.length()) out.add(a.getJSONObject(i).getString("id"))
            }
            "gemini" -> {
                val r = JSONObject(Net.get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", mapOf("x-goog-api-key" to key)))
                val a = r.optJSONArray("models") ?: JSONArray()
                for (i in 0 until a.length()) {
                    val m = a.getJSONObject(i)
                    val methods = m.optJSONArray("supportedGenerationMethods")
                    var gen = methods == null
                    if (methods != null) {
                        for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") gen = true
                    }
                    if (gen) out.add(m.getString("name").removePrefix("models/"))
                }
            }
            else -> {
                val base = (if (p.id == "custom") Prefs.get(c, "custom_url") else p.url).substringBefore("/chat/completions")
                val r = JSONObject(Net.get("$base/models", mapOf("Authorization" to "Bearer $key")))
                val a = r.optJSONArray("data") ?: JSONArray()
                for (i in 0 until a.length()) out.add(a.getJSONObject(i).getString("id"))
            }
        }
        return out
    }

    private fun versionOf(id: String): Double =
        Regex("(\\d+(?:\\.\\d+)?)").find(id)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0

    private fun pickModel(c: Context, p: P, key: String, bad: String): String? {
        val l = listModels(c, p, key)
        if (l.isEmpty()) return null
        return when (p.id) {
            "gemini" -> {
                val skip = listOf("lite", "image", "tts", "live", "audio", "embedding", "robotics", "computer", "learnlm", "gemma", "thinking")
                val flash = l.filter { it.contains("flash") && skip.none { s -> it.contains(s) } && it != bad }
                if (flash.contains("gemini-flash-latest")) "gemini-flash-latest" else flash.maxByOrNull { versionOf(it) }
            }
            "claude" -> {
                if (l.contains(p.model) && p.model != bad) p.model else l.firstOrNull { it.contains("sonnet") } ?: l.firstOrNull()
            }
            else -> if (l.contains(p.model) && p.model != bad) p.model else null
        }
    }

    // ---------- error text ----------
    private fun extractMsg(body: String): String {
        try {
            val t = body.trim()
            if (t.startsWith("[")) {
                return JSONArray(t).getJSONObject(0).getJSONObject("error").optString("message")
            }
            val o = JSONObject(t)
            val e = o.opt("error")
            if (e is JSONObject) return e.optString("message")
            if (e is String) return e
            return o.optString("message")
        } catch (_: Exception) {
        }
        return body.take(200)
    }

    fun friendly(p: P, e: Exception): String {
        if (e is Net.HttpError) {
            val msg = extractMsg(e.body).take(300)
            val low = msg.lowercase()
            return when {
                low.contains("anthropic-workspace-id") || (p.id == "claude" && low.contains("workspace")) ->
                    "This Claude key needs a Workspace ID. Open Settings, paste the ID (it starts with wrkspc_) in the Workspace ID box, and try again. You can copy it from the Anthropic Console under Settings > Workspaces."
                e.code == 401 || e.code == 403 ->
                    "${p.label} rejected the API key (HTTP ${e.code}). Check Settings: the key may be wrong, expired or missing permission.\n$msg"
                e.code == 404 ->
                    "That model isn't available any more. Open Settings and tap \"Find models\" to pick a current one.\n$msg"
                e.code == 429 ->
                    "${p.label} says you've hit a rate limit or quota. Wait a minute, or check billing for this key.\n$msg"
                e.code >= 500 ->
                    "${p.label} is having trouble right now (HTTP ${e.code}). Please try again in a moment."
                else -> "${p.label} error (HTTP ${e.code}): $msg"
            }
        }
        if (e is java.net.UnknownHostException) return "No internet connection."
        if (e is java.net.SocketTimeoutException) return "The AI took too long to answer. Please try again."
        return "Something went wrong: ${e.message}"
    }
}
