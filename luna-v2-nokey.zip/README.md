# Luna 2.1

Build: put this zip in your GitHub repo, then Actions > "Build Luna APK" > Releases > Luna.apk.

No AI key? Luna still works: apps, calls, messages, alarms, weather, news, currency, quick facts and maths.
For open chat: Settings > pick a provider (Gemini or OpenRouter have free keys), paste the key, tap Test.
A key pasted under the wrong provider (sk-or-... = OpenRouter, AIza... = Gemini, gsk_... = Groq) is detected automatically.
