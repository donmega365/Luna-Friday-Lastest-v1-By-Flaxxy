package com.luna.assistant

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {
    private var lastNum = ""
    private var lastAt = 0L

    override fun onReceive(c: Context, i: Intent) {
        try {
            handle(c, i)
        } catch (e: Exception) {
            AppLog.add(c, "Call handler error: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    private fun smsDefault(): SmsManager = SmsManager.getDefault()

    private fun sms(c: Context, num: String, msg: String) {
        if (c.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            val sm = if (android.os.Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else smsDefault()
            val parts = sm.divideMessage(msg)
            if (parts.size > 1) sm.sendMultipartTextMessage(num, null, parts, null, null) else sm.sendTextMessage(num, null, msg, null, null)
            AppLog.add(c, "SMS sent to caller")
        } else {
            AppLog.add(c, "Can't send SMS: SMS permission missing")
        }
    }

    private fun handle(c: Context, i: Intent) {
        if (i.getStringExtra(TelephonyManager.EXTRA_STATE) != TelephonyManager.EXTRA_STATE_RINGING) return
        if (!Prefs.getBool(c, "busy")) return
        val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        if (num.isNullOrBlank()) {
            AppLog.add(c, "Incoming call: caller number not delivered yet (needs Call log + Phone state permissions)")
            return
        }
        val now = System.currentTimeMillis()
        if (num == lastNum && now - lastAt < 30000) return
        val name = Contacts.nameFor(c, num) ?: (if (Prefs.getList(c, "busy_friends").any { Contacts.sameAs(c, it, num) }) num else null)
        if (name == null) {
            AppLog.add(c, "Call from $num ignored (not in your contacts, or Contacts permission missing)")
            return
        }
        val allowed = Prefs.getList(c, "busy_friends")
        if (allowed.none { Contacts.sameAs(c, it, name) || Contacts.sameAs(c, it, num) }) {
            AppLog.add(c, "Call from '$name' ignored (not in your call list)")
            return
        }
        if (c.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            AppLog.add(c, "Can't handle call: Answer/end calls permission missing")
            return
        }
        lastNum = num
        lastAt = now

        val msg = Prefs.get(c, "call_msg").ifBlank { Prefs.get(c, "busy_msg", Defaults.MSG) }
        val tm = c.getSystemService(TelecomManager::class.java)
        val h = Handler(Looper.getMainLooper())
        val action = Prefs.get(c, "call_action", "sms")
        AppLog.add(c, "Handling call from '$name' (mode: $action)")

        when (action) {
            "answer" -> {
                tm.acceptRingingCall()
                h.postDelayed({
                    val am = c.getSystemService(AudioManager::class.java)
                    am.isSpeakerphoneOn = true
                    Speaker.speak(c, msg)
                }, 1500)
                h.postDelayed({
                    try {
                        tm.endCall()
                    } catch (_: Exception) {
                    }
                }, 14000)
            }
            "wa" -> {
                tm.endCall()
                if (WaSender.accessibilityOn(c)) {
                    WaSender.send(c, num, msg)
                } else {
                    AppLog.add(c, "WhatsApp auto-send is OFF, sending SMS instead")
                    sms(c, num, msg)
                }
            }
            else -> {
                tm.endCall()
                sms(c, num, msg)
            }
        }
    }
}
