package com.luna.assistant

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Net {
    class HttpError(val code: Int, val body: String) : Exception("HTTP $code")

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun readLimited(s: InputStream, max: Int): String {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (out.size() < max) {
            val n = s.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
        }
        return out.toString("UTF-8")
    }

    fun request(
        method: String,
        url: String,
        headers: Map<String, String> = emptyMap(),
        body: String? = null,
        readTimeoutMs: Int = 25000,
        maxBytes: Int = 600000
    ): String {
        val con = URL(url).openConnection() as HttpURLConnection
        try {
            con.requestMethod = method
            con.connectTimeout = 15000
            con.readTimeout = readTimeoutMs
            con.instanceFollowRedirects = true
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Luna/2.0")
            headers.forEach { (k, v) -> con.setRequestProperty(k, v) }
            if (body != null) {
                con.doOutput = true
                if (headers.keys.none { it.equals("Content-Type", true) }) {
                    con.setRequestProperty("Content-Type", "application/json")
                }
                con.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = con.responseCode
            val stream = if (code in 200..299) con.inputStream else con.errorStream
            val txt = if (stream != null) stream.use { readLimited(it, maxBytes) } else ""
            if (code !in 200..299) throw HttpError(code, txt)
            return txt
        } finally {
            con.disconnect()
        }
    }

    fun get(url: String, headers: Map<String, String> = emptyMap(), maxBytes: Int = 600000): String =
        request("GET", url, headers, null, 25000, maxBytes)

    fun post(url: String, headers: Map<String, String>, body: String, readTimeoutMs: Int = 60000): String =
        request("POST", url, headers, body, readTimeoutMs)
}
