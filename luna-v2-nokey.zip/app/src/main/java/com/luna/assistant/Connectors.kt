package com.luna.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.net.URI
import java.util.Locale

object Connectors {
    class Builtin(val id: String, val title: String, val sub: String, val icon: Int)

    class Custom(
        val id: String,
        var name: String,
        var desc: String,
        var method: String,
        var url: String,
        var headers: String,
        var body: String,
        var enabled: Boolean
    )

    class Preset(val title: String, val method: String, val url: String, val headers: String, val body: String, val desc: String)

    val builtins = listOf(
        Builtin("weather", "Weather", "Current weather and a 3-day forecast for any city", R.drawable.ic_cloud),
        Builtin("news", "News", "Top headlines or news about a topic", R.drawable.ic_news),
        Builtin("lookup", "Quick facts", "Short answers from Wikipedia and DuckDuckGo", R.drawable.ic_book),
        Builtin("websearch", "Web search", "Search results from the web", R.drawable.ic_globe),
        Builtin("fx", "Currency", "Live exchange rates, e.g. 100 USD to PKR", R.drawable.ic_coin),
        Builtin("readurl", "Read a website", "Opens a link and lets the AI summarise the page", R.drawable.ic_globe)
    )

    val presets = listOf(
        Preset("Blank webhook", "POST", "https://", "", "{\"input\": \"{input}\"}", "Describe when the AI should use this."),
        Preset("Telegram bot message", "POST", "https://api.telegram.org/bot<BOT_TOKEN>/sendMessage", "Content-Type: application/json", "{\"chat_id\":\"<CHAT_ID>\",\"text\":\"{input}\"}", "Send a Telegram message to me. input is the message text."),
        Preset("ntfy notification", "POST", "https://ntfy.sh/<YOUR_TOPIC>", "Content-Type: text/plain", "{input_raw}", "Send a push notification to my devices. input is the text."),
        Preset("IFTTT trigger", "GET", "https://maker.ifttt.com/trigger/<EVENT>/with/key/<KEY>?value1={input}", "", "", "Trigger my IFTTT applet. input is passed as value1."),
        Preset("Discord webhook", "POST", "https://discord.com/api/webhooks/<ID>/<TOKEN>", "Content-Type: application/json", "{\"content\":\"{input}\"}", "Post a message to my Discord channel."),
        Preset("Slack webhook", "POST", "https://hooks.slack.com/services/<PATH>", "Content-Type: application/json", "{\"text\":\"{input}\"}", "Post a message to my Slack channel."),
        Preset("Home Assistant webhook", "POST", "http://homeassistant.local:8123/api/webhook/<WEBHOOK_ID>", "Content-Type: application/json", "{\"command\":\"{input}\"}", "Control my smart home. input is the command, e.g. lights off."),
        Preset("Any REST API (GET)", "GET", "https://api.example.com/search?q={input}", "Authorization: Bearer <TOKEN>", "", "Look something up in my API. input is the query.")
    )

    fun builtinOn(c: Context, id: String) = Prefs.getBool(c, "conn_$id", true)

    fun setBuiltin(c: Context, id: String, on: Boolean) = Prefs.putBool(c, "conn_$id", on)

    fun customList(c: Context): MutableList<Custom> {
        val out = ArrayList<Custom>()
        try {
            val a = JSONArray(Prefs.get(c, "connectors_custom", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Custom(
                        o.optString("id"), o.optString("name"), o.optString("desc"), o.optString("method", "GET"),
                        o.optString("url"), o.optString("headers"), o.optString("body"), o.optBoolean("enabled", true)
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun saveCustom(c: Context, l: List<Custom>) {
        val a = JSONArray()
        for (x in l) {
            a.put(
                JSONObject().put("id", x.id).put("name", x.name).put("desc", x.desc).put("method", x.method)
                    .put("url", x.url).put("headers", x.headers).put("body", x.body).put("enabled", x.enabled)
            )
        }
        Prefs.put(c, "connectors_custom", a.toString())
    }

    fun isWrite(c: Context, name: String): Boolean {
        val cn = customList(c).firstOrNull { it.name.equals(name, true) } ?: return false
        return !cn.method.equals("GET", true)
    }
}

// Runs a tool and returns plain text. Always call from a background thread.
object Tools {
    fun run(c: Context, cmd: Cmd): String {
        return try {
            when (cmd.kind) {
                "weather" -> if (Connectors.builtinOn(c, "weather")) weather(c, cmd.a) else off("Weather")
                "news" -> if (Connectors.builtinOn(c, "news")) news(cmd.a) else off("News")
                "lookup" -> if (Connectors.builtinOn(c, "lookup")) lookup(cmd.a) else off("Quick facts")
                "websearch" -> if (Connectors.builtinOn(c, "websearch")) webSearch(c, cmd.a) else off("Web search")
                "fx" -> if (Connectors.builtinOn(c, "fx")) fx(cmd.a, cmd.b, cmd.c) else off("Currency")
                "readurl" -> if (Connectors.builtinOn(c, "readurl")) readUrl(cmd.a) else off("Read a website")
                "connector" -> custom(c, cmd.a, cmd.b)
                else -> "Unknown tool."
            }
        } catch (e: Net.HttpError) {
            "The service answered with HTTP ${e.code}."
        } catch (e: java.net.UnknownHostException) {
            "No internet connection."
        } catch (e: java.net.SocketTimeoutException) {
            "The service took too long to answer."
        } catch (e: Exception) {
            "Could not complete that: ${e.message}"
        }
    }

    private fun off(n: String) = "$n is turned off in the Connect tab."

    private fun clip(s: String, n: Int) = if (s.length > n) s.take(n) + "..." else s

    private fun unescape(s: String): String =
        s.replace("<![CDATA[", "").replace("]]>", "")
            .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
            .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ").replace("&#x27;", "'")
            .trim()

    private fun stripTags(s: String): String =
        unescape(s.replace(Regex("(?s)<[^>]+>"), " ")).replace(Regex("\\s+"), " ").trim()

    // ---------- weather ----------
    private fun wmo(code: Int): String = when (code) {
        0 -> "clear sky"
        1 -> "mostly clear"
        2 -> "partly cloudy"
        3 -> "overcast"
        45, 48 -> "fog"
        51, 53, 55, 56, 57 -> "drizzle"
        61, 63, 65, 66, 67 -> "rain"
        71, 73, 75, 77 -> "snow"
        80, 81, 82 -> "rain showers"
        85, 86 -> "snow showers"
        95, 96, 99 -> "thunderstorm"
        else -> "mixed conditions"
    }

    fun weather(c: Context, place0: String): String {
        val place = place0.ifBlank { Prefs.get(c, "home_city") }
        if (place.isBlank()) return "Which city? You can also set a home city in the Connect tab."
        val g = JSONObject(Net.get("https://geocoding-api.open-meteo.com/v1/search?name=" + Net.enc(place) + "&count=1&language=en&format=json"))
        val res = g.optJSONArray("results")
        if (res == null || res.length() == 0) return "I couldn't find a place called '$place'."
        val p = res.getJSONObject(0)
        val label = p.optString("name") + (if (p.optString("country").isNotBlank()) ", " + p.optString("country") else "")
        val url = "https://api.open-meteo.com/v1/forecast?latitude=" + p.getDouble("latitude") + "&longitude=" + p.getDouble("longitude") +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=3"
        val w = JSONObject(Net.get(url))
        val cur = w.getJSONObject("current")
        val d = w.getJSONObject("daily")
        val sb = StringBuilder()
        sb.append(label).append(" now: ").append(Math.round(cur.getDouble("temperature_2m"))).append("\u00B0C")
        sb.append(" (feels ").append(Math.round(cur.getDouble("apparent_temperature"))).append("\u00B0C), ")
        sb.append(wmo(cur.getInt("weather_code"))).append(", humidity ").append(cur.getInt("relative_humidity_2m")).append("%, wind ")
        sb.append(Math.round(cur.getDouble("wind_speed_10m"))).append(" km/h.")
        val days = d.getJSONArray("time")
        val hi = d.getJSONArray("temperature_2m_max")
        val lo = d.getJSONArray("temperature_2m_min")
        val rain = d.getJSONArray("precipitation_probability_max")
        val wc = d.getJSONArray("weather_code")
        val names = listOf("Today", "Tomorrow", "Day after")
        for (i in 0 until minOf(3, days.length())) {
            sb.append("\n").append(names[i]).append(": ").append(Math.round(lo.getDouble(i))).append("\u2013")
            sb.append(Math.round(hi.getDouble(i))).append("\u00B0C, ").append(wmo(wc.getInt(i)))
            sb.append(", rain chance ").append(rain.optInt(i)).append("%")
        }
        return sb.toString()
    }

    // ---------- news ----------
    private fun newsItems(url: String): List<String> {
        val xml = Net.get(url)
        return Regex("(?s)<item>.*?<title>(.*?)</title>").findAll(xml).map { unescape(it.groupValues[1]) }.filter { it.isNotBlank() }.take(6).toList()
    }

    fun news(topic: String): String {
        val cc = Locale.getDefault().country.ifBlank { "US" }
        val base = if (topic.isBlank()) "https://news.google.com/rss" else "https://news.google.com/rss/search?q=" + Net.enc(topic)
        val sep = if (base.contains("?")) "&" else "?"
        var items = try {
            newsItems("$base${sep}hl=en-$cc&gl=$cc&ceid=$cc:en")
        } catch (_: Exception) {
            emptyList()
        }
        if (items.isEmpty()) items = newsItems("$base${sep}hl=en-US&gl=US&ceid=US:en")
        if (items.isEmpty()) return "No headlines found."
        return (if (topic.isBlank()) "Top headlines:\n" else "News about $topic:\n") + items.joinToString("\n") { "- $it" }
    }

    // ---------- quick facts ----------
    fun lookup(q: String): String {
        if (q.isBlank()) return "What should I look up?"
        try {
            val d = JSONObject(Net.get("https://api.duckduckgo.com/?q=" + Net.enc(q) + "&format=json&no_html=1&skip_disambig=1&t=luna"))
            val abs = d.optString("AbstractText")
            if (abs.isNotBlank()) return clip(abs, 900) + " (" + d.optString("AbstractSource", "DuckDuckGo") + ")"
            val ans = d.optString("Answer")
            if (ans.isNotBlank()) return clip(ans, 500)
        } catch (_: Exception) {
        }
        val s = JSONObject(Net.get("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=" + Net.enc(q) + "&srlimit=1&format=json&utf8=1"))
        val hits = s.getJSONObject("query").getJSONArray("search")
        if (hits.length() == 0) return "No quick answer found for '$q'."
        val title = hits.getJSONObject(0).getString("title")
        val sum = JSONObject(Net.get("https://en.wikipedia.org/api/rest_v1/page/summary/" + Net.enc(title.replace(" ", "_"))))
        return clip(sum.optString("extract", "No summary available."), 900) + " (Wikipedia: " + title + ")"
    }

    // ---------- web search ----------
    fun webSearch(c: Context, q: String): String {
        if (q.isBlank()) return "What should I search for?"
        val brave = Prefs.get(c, "key_brave").trim()
        if (brave.isNotEmpty()) {
            val r = JSONObject(Net.get("https://api.search.brave.com/res/v1/web/search?count=5&q=" + Net.enc(q), mapOf("X-Subscription-Token" to brave, "Accept" to "application/json")))
            val arr = r.optJSONObject("web")?.optJSONArray("results")
            if (arr != null && arr.length() > 0) {
                val sb = StringBuilder()
                for (i in 0 until minOf(5, arr.length())) {
                    val o = arr.getJSONObject(i)
                    sb.append("- ").append(stripTags(o.optString("title"))).append(" | ").append(o.optString("url")).append("\n  ")
                    sb.append(clip(stripTags(o.optString("description")), 220)).append("\n")
                }
                return sb.toString().trim()
            }
        }
        val html = Net.get("https://html.duckduckgo.com/html/?q=" + Net.enc(q))
        val links = Regex("(?s)<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>").findAll(html).toList()
        val snips = Regex("(?s)<a[^>]*class=\"result__snippet\"[^>]*>(.*?)</a>").findAll(html).toList()
        if (links.isEmpty()) return lookup(q)
        val sb = StringBuilder()
        for (i in 0 until minOf(5, links.size)) {
            var href = unescape(links[i].groupValues[1])
            val m = Regex("uddg=([^&]+)").find(href)
            if (m != null) href = java.net.URLDecoder.decode(m.groupValues[1], "UTF-8")
            sb.append("- ").append(stripTags(links[i].groupValues[2])).append(" | ").append(href).append("\n")
            if (i < snips.size) sb.append("  ").append(clip(stripTags(snips[i].groupValues[1]), 220)).append("\n")
        }
        return sb.toString().trim()
    }

    // ---------- currency ----------
    fun fx(amount: String, from: String, to: String): String {
        val a = amount.replace(",", "").toDoubleOrNull() ?: return "I couldn't read the amount."
        if (from.length != 3 || to.length != 3) return "Use 3-letter currency codes, e.g. USD to PKR."
        val r = JSONObject(Net.get("https://open.er-api.com/v6/latest/$from"))
        if (r.optString("result") != "success") return "Unknown currency '$from'."
        val rate = r.getJSONObject("rates").optDouble(to, Double.NaN)
        if (rate.isNaN()) return "Unknown currency '$to'."
        return String.format(Locale.US, "%,.2f %s = %,.2f %s (rate %.4f)", a, from, a * rate, to, rate)
    }

    // ---------- read a website ----------
    private fun blocked(host: String): Boolean {
        if (host.isBlank()) return true
        return try {
            val a = InetAddress.getByName(host)
            a.isLoopbackAddress || a.isSiteLocalAddress || a.isLinkLocalAddress || a.isAnyLocalAddress
        } catch (_: Exception) {
            false
        }
    }

    fun readUrl(u0: String): String {
        var u = u0.trim()
        if (u.isEmpty()) return "Which link?"
        if (!u.startsWith("http")) u = "https://$u"
        val host = try {
            URI(u).host ?: ""
        } catch (_: Exception) {
            ""
        }
        if (blocked(host)) return "That address isn't allowed."
        val html = Net.get(u, emptyMap(), 400000)
        val title = Regex("(?is)<title[^>]*>(.*?)</title>").find(html)?.groupValues?.get(1)?.let { stripTags(it) } ?: ""
        val body = stripTags(html.replace(Regex("(?is)<(script|style|noscript|svg|head|nav|footer)[^>]*>.*?</\\1>"), " "))
        return (if (title.isNotBlank()) "Title: $title\n" else "") + clip(body, 3500)
    }

    // ---------- custom connectors ----------
    private fun headerMap(h: String, fill: (String) -> String): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        for (line in h.lines()) {
            val i = line.indexOf(':')
            if (i > 0) m[line.substring(0, i).trim()] = fill(line.substring(i + 1).trim())
        }
        return m
    }

    fun custom(c: Context, name: String, input: String): String {
        val cn = Connectors.customList(c).firstOrNull { it.name.equals(name, true) && it.enabled }
            ?: return "There is no connector named '$name'."
        return runCustom(cn, input)
    }

    fun runCustom(cn: Connectors.Custom, input: String): String {
        val q = JSONObject.quote(input)
        val jsonIn = q.substring(1, q.length - 1)
        fun fill(t: String, url: Boolean): String =
            t.replace("{input_raw}", input).replace("{input}", if (url) Net.enc(input) else jsonIn)
        val url = fill(cn.url, true)
        val headers = headerMap(cn.headers) { fill(it, false) }
        val method = cn.method.uppercase()
        val txt = if (method == "GET") {
            Net.request("GET", url, headers, null, 25000, 60000)
        } else {
            val body = if (cn.body.isBlank()) input else fill(cn.body, false)
            val hs = LinkedHashMap(headers)
            if (hs.keys.none { it.equals("Content-Type", true) }) hs["Content-Type"] = if (cn.body.isBlank()) "text/plain" else "application/json"
            Net.request(method, url, hs, body, 25000, 60000)
        }
        val out = txt.trim()
        return if (out.isEmpty()) "Done (the service returned no text)." else clip(stripTags(out).ifBlank { out }, 1500)
    }
}
