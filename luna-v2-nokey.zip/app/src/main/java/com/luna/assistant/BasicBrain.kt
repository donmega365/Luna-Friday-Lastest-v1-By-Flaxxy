package com.luna.assistant

import android.content.Context

// Works with NO AI key: small talk, maths, quick facts (Wikipedia / DuckDuckGo) and a pointer to what Luna can do.
// Always call from a background thread.
object BasicBrain {
    private fun pick(lang: String, en: String, hi: String, ur: String): String = when (lang) {
        "hi" -> hi
        "ur" -> ur
        else -> en
    }

    private val greet = listOf(
        "hi", "hii", "hello", "helo", "hey", "hola", "salam", "salaam", "assalamualaikum", "assalamu alaikum",
        "assalam o alaikum", "namaste", "नमस्ते", "सलाम", "हेलो", "سلام", "السلام علیکم", "ہیلو"
    )
    private val thanks = listOf("thanks", "thank you", "thx", "shukriya", "shukria", "dhanyavad", "शुक्रिया", "धन्यवाद", "शुक्रिया", "شکریہ")
    private val howAre = listOf("how are you", "kaise ho", "kaisi ho", "kaise hain", "kya haal", "आप कैसे", "कैसे हो", "کیسے ہو", "کیا حال")
    private val whoAre = listOf("who are you", "your name", "tum kaun ho", "aap kaun ho", "tumhara naam", "aapka naam", "तुम कौन", "आप कौन", "تم کون", "آپ کون")
    private val helpWords = listOf("help", "what can you do", "kya kar sakte", "kya kar sakti", "kya kar sakta", "कर सकते", "कर सकती", "کر سکتے", "کر سکتی")

    private val qPrefix = Regex("^(what is|what are|what was|what's|who is|who was|who are|who's|tell me about|explain|define|meaning of|search for|kya hai|kaun hai|kaun tha|batao|bataiye)\\s+")
    private val qSuffix = Regex("\\s+(kya hai|kya hota hai|kaun hai|kaun tha|ke bare mein batao|ke baare me batao|ka matlab|ke bare me|in english)$")

    fun answer(c: Context, text: String, online: Boolean): String {
        val lang = L.detect(c, text)
        val name = Prefs.get(c, "name", "Luna")
        val l = text.trim().lowercase().trim('?', '.', '!', ' ', '،', '؟')

        if (greet.any { l == it || l.startsWith("$it ") }) {
            return pick(
                lang,
                "Hi! I'm $name. I work without an AI key for commands, weather, news, currency, quick facts and maths. Say \"help\" to see examples.",
                "नमस्ते! मैं $name हूँ। मैं बिना AI key के कमांड, मौसम, ख़बरें, करेंसी, जानकारी और हिसाब कर सकता हूँ। \"help\" बोलिए।",
                "السلام علیکم! میں $name ہوں۔ میں بغیر AI key کے کمانڈ، موسم، خبریں، کرنسی، معلومات اور حساب کر سکتا ہوں۔ \"help\" بولیں۔"
            )
        }
        if (thanks.any { l.contains(it) }) {
            return pick(lang, "You're welcome!", "आपका स्वागत है!", "خوش آمدید!")
        }
        if (howAre.any { l.contains(it) }) {
            return pick(lang, "I'm doing great, thanks! How can I help?", "मैं बढ़िया हूँ, शुक्रिया! बताइए क्या करूँ?", "میں بہت اچھا ہوں، شکریہ! بتائیں کیا کروں؟")
        }
        if (whoAre.any { l.contains(it) }) {
            return pick(lang, "I'm $name, your phone assistant.", "मैं $name हूँ, आपका फ़ोन असिस्टेंट।", "میں $name ہوں، آپ کا فون اسسٹنٹ۔")
        }
        if (l == "help" || helpWords.any { l.contains(it) }) return helpText(lang)

        tryMath(l)?.let { return it }

        var q = l
        val m1 = qPrefix.containsMatchIn(q)
        q = qPrefix.replace(q, "")
        val m2 = qSuffix.containsMatchIn(q)
        q = qSuffix.replace(q, "")
        q = q.removePrefix("a ").removePrefix("an ").removePrefix("the ").trim()
        val topic = m1 || m2 || q.split(" ").size <= 4
        if (q.length >= 2 && topic) {
            if (!online) {
                return pick(lang, "I'm offline, so I can't look that up right now.", "अभी ऑफ़लाइन हूँ, इसलिए ये खोज नहीं सकता।", "ابھی آف لائن ہوں، اس لیے یہ تلاش نہیں کر سکتا۔")
            }
            val r = Tools.run(c, Cmd("lookup", q))
            if (!r.startsWith("No quick answer") && !r.startsWith("Could not") && !r.startsWith("Unknown")) return r
        }
        return pick(
            lang,
            "I can't hold a free conversation without an AI key, but I can open apps, call, message, set alarms, and check weather, news, currency, quick facts and maths. For open chat, add a free key (Gemini or OpenRouter) in Settings.",
            "बिना AI key के मैं खुली बातचीत नहीं कर सकता, लेकिन ऐप खोलना, कॉल, मैसेज, अलार्म, मौसम, ख़बरें, करेंसी, जानकारी और हिसाब कर सकता हूँ। खुली चैट के लिए Settings में free key (Gemini या OpenRouter) डालिए।",
            "بغیر AI key کے میں کھلی گفتگو نہیں کر سکتا، لیکن ایپ کھولنا، کال، میسج، الارم، موسم، خبریں، کرنسی، معلومات اور حساب کر سکتا ہوں۔ کھلی چیٹ کے لیے Settings میں free key (Gemini یا OpenRouter) ڈالیں۔"
        )
    }

    private fun helpText(lang: String): String = pick(
        lang,
        "Try: \"open youtube\", \"call Ali\", \"whatsapp message Ali I'm busy\", \"alarm 7:30\", \"timer 5 minutes\", \"weather Lahore\", \"news\", \"100 usd to pkr\", \"who is Albert Einstein\", \"25 * 4\".",
        "बोलिए: \"open youtube\", \"call Ali\", \"whatsapp message Ali busy hu\", \"alarm 7:30\", \"timer 5 minutes\", \"weather Delhi\", \"news\", \"100 usd to inr\", \"who is Albert Einstein\", \"25 * 4\".",
        "بولیں: \"open youtube\", \"call Ali\", \"whatsapp message Ali busy hun\", \"alarm 7:30\", \"timer 5 minutes\", \"weather Lahore\", \"news\", \"100 usd to pkr\", \"who is Albert Einstein\", \"25 * 4\"."
    )

    // ---------- maths ----------
    private fun tryMath(raw: String): String? {
        var s = raw.lowercase()
        Regex("(\\d+(?:\\.\\d+)?)\\s*(?:%|percent|percentage)\\s*(?:of|ka|ki)\\s*(\\d+(?:\\.\\d+)?)").find(s)?.let {
            return "= " + fmt(it.groupValues[1].toDouble() * it.groupValues[2].toDouble() / 100.0)
        }
        s = s.replace("×", "*").replace("÷", "/").replace("plus", "+").replace("minus", "-")
            .replace("multiplied by", "*").replace("times", "*").replace("into", "*").replace("divided by", "/").replace(",", "")
        s = Regex("(?<=\\d)\\s*x\\s*(?=\\d)").replace(s, "*")
        s = Regex("^(what is|what's|calculate|calc|solve|compute|find)\\s+").replace(s.trim(), "")
        s = s.replace("=", "").replace("?", "").trim()
        if (s.isEmpty() || !Regex("^[0-9+\\-*/^().% ]+$").matches(s)) return null
        if (!Regex("[+\\-*/^%]").containsMatchIn(s.trimStart('-'))) return null
        return try {
            "= " + fmt(Calc(s.replace("%", "/100")).parse())
        } catch (_: Exception) {
            null
        }
    }

    private fun fmt(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return "can't be calculated"
        return if (v == Math.floor(v) && Math.abs(v) < 1e15) {
            v.toLong().toString()
        } else {
            String.format(java.util.Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
        }
    }

    private class Calc(val s: String) {
        var i = 0

        fun parse(): Double {
            val v = expr()
            ws()
            if (i < s.length) throw IllegalArgumentException("extra input")
            return v
        }

        fun ws() {
            while (i < s.length && s[i] == ' ') i++
        }

        fun expr(): Double {
            var v = term()
            while (true) {
                ws()
                if (i < s.length && (s[i] == '+' || s[i] == '-')) {
                    val op = s[i++]
                    val r = term()
                    v = if (op == '+') v + r else v - r
                } else {
                    return v
                }
            }
        }

        fun term(): Double {
            var v = pow()
            while (true) {
                ws()
                if (i < s.length && (s[i] == '*' || s[i] == '/')) {
                    val op = s[i++]
                    val r = pow()
                    v = if (op == '*') v * r else v / r
                } else {
                    return v
                }
            }
        }

        fun pow(): Double {
            val b = unary()
            ws()
            if (i < s.length && s[i] == '^') {
                i++
                return Math.pow(b, pow())
            }
            return b
        }

        fun unary(): Double {
            ws()
            if (i < s.length && s[i] == '-') {
                i++
                return -unary()
            }
            if (i < s.length && s[i] == '+') {
                i++
                return unary()
            }
            return atom()
        }

        fun atom(): Double {
            ws()
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                ws()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException("missing )")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("number expected")
            return s.substring(st, i).toDouble()
        }
    }
}
