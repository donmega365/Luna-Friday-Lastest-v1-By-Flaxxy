package com.luna.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import java.text.Normalizer

// Name matching that copes with Roman Urdu / Hindi spelling (Muzammil = Muzamil = Mujammil),
// titles (bhai, sir, ji ...), short forms ("mz" -> Muzammil) and small typos.
object Names {
    private val honorifics = setOf(
        "bhai", "bhaiya", "bhaijan", "bro", "sir", "sahab", "sahib", "saab", "ji", "mr", "mrs", "ms",
        "dr", "ustad", "baji", "apa", "didi", "uncle", "aunty", "auntie", "madam", "mam"
    )

    fun clean(s: String): String {
        var t = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
        t = t.replace(Regex("[\\u0300-\\u036f]+"), "")
        t = t.replace(Regex("[^a-z0-9\\u0600-\\u06ff\\u0900-\\u097f ]"), " ")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    fun tokens(s: String): List<String> = clean(s).split(" ").filter { it.isNotBlank() }

    fun core(t: List<String>): List<String> {
        val r = t.filter { it !in honorifics }
        return if (r.isEmpty()) t else r
    }

    fun phon(w: String): String {
        var t = w
        val reps = listOf(
            "ph" to "f", "ck" to "k", "q" to "k", "w" to "v", "z" to "j", "x" to "ks", "y" to "i",
            "ee" to "i", "ii" to "i", "oo" to "u", "uu" to "u", "aa" to "a", "ou" to "u", "ai" to "e"
        )
        for ((a, b) in reps) t = t.replace(a, b)
        return t.replace(Regex("(.)\\1+"), "$1")
    }

    private fun skel(p: String): String {
        if (p.length <= 1) return p
        return p.take(1) + p.drop(1).replace(Regex("[aeiou]"), "")
    }

    // stable key used to store nicknames and remembered numbers
    fun key(s: String): String = tokens(s).joinToString(" ") { phon(it) }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    private fun tokenScore(q: String, c: String): Double {
        if (q == c) return 1.0
        val pq = phon(q)
        val pc = phon(c)
        if (pq == pc) return 0.92
        if (q.length >= 2 && c.startsWith(q)) return 0.85
        if (pq.length >= 2 && pc.startsWith(pq)) return 0.82
        val m = maxOf(pq.length, pc.length)
        val d = lev(pq, pc)
        if (m >= 4 && d <= 1) return 0.78
        if (m >= 7 && d <= 2) return 0.66
        val sq = skel(pq)
        val sc = skel(pc)
        if (sq.length >= 2 && sq == sc) return 0.7
        if (sq.length >= 2 && pq.length <= 3 && sc.startsWith(sq)) return 0.65
        return 0.0
    }

    // 0..100
    fun score(query: String, name: String): Int {
        val qAll = tokens(query)
        val cAll = tokens(name)
        if (qAll.isEmpty() || cAll.isEmpty()) return 0
        if (qAll == cAll) return 100
        val q = core(qAll)
        val c = cAll
        if (core(qAll) == core(cAll)) return 96
        var total = 0.0
        for (t in q) {
            var best = 0.0
            for (x in c) {
                val s = tokenScore(t, x)
                if (s > best) best = s
            }
            if (best <= 0.0) return 0
            total += best
        }
        var s = total / q.size * 90.0
        s -= (c.size - q.size).coerceAtLeast(0) * 2
        return s.toInt().coerceIn(0, 95)
    }
}

class Person(val name: String, val numbers: List<Pair<String, Int>>)

class Pick(val name: String, val number: String, val label: String = "")

sealed class Resolved {
    class One(val pick: Pick) : Resolved()
    class Many(val query: String, val options: List<Pick>, val sameContact: Boolean) : Resolved()
    object None : Resolved()
}

object Contacts {
    private var cache: List<Person>? = null
    private var cacheAt = 0L

    fun ok(c: Context) =
        c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun invalidate() {
        cache = null
    }

    private class Acc(val name: String) {
        val nums = ArrayList<Pair<String, Int>>()
    }

    fun all(c: Context): List<Person> {
        val now = System.currentTimeMillis()
        val cached = cache
        if (cached != null && now - cacheAt < 120000L) return cached
        val out = ArrayList<Person>()
        if (ok(c)) {
            try {
                val map = LinkedHashMap<String, Acc>()
                val cols = arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.TYPE
                )
                c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null, null)?.use { cur ->
                    while (cur.moveToNext()) {
                        val id = cur.getString(0) ?: continue
                        val name = cur.getString(1) ?: continue
                        val num = cur.getString(2) ?: continue
                        val type = cur.getInt(3)
                        val acc = map.getOrPut(id) { Acc(name) }
                        if (acc.nums.none { Learned.tail(it.first) == Learned.tail(num) }) acc.nums.add(Pair(num, type))
                    }
                }
                for (a in map.values) out.add(Person(a.name, a.nums))
            } catch (_: Exception) {
            }
        }
        // numbers Luna learned earlier that are not in the phone book (or Contacts permission is off)
        for ((n, p) in Learned.pairs(c)) {
            val known = out.any { person -> person.numbers.any { Learned.tail(it.first) == Learned.tail(p) } }
            if (!known) out.add(Person(n, listOf(Pair(p, 2))))
        }
        cache = out
        cacheAt = now
        return out
    }

    fun nameFor(c: Context, number: String): String? {
        if (number.isBlank()) return null
        if (ok(c)) {
            try {
                val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
                c.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) {
                        val n = it.getString(0)
                        if (!n.isNullOrBlank()) {
                            Learned.remember(c, n, number)
                            return n
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        return Learned.nameForNumber(c, number)
    }

    private fun typeLabel(t: Int) = when (t) {
        1 -> "Home"
        2 -> "Mobile"
        3 -> "Work"
        else -> "Other"
    }

    private fun picksOf(p: Person): List<Pick> = p.numbers.map { Pick(p.name, it.first, typeLabel(it.second)) }

    private fun bestOf(p: Person): Pick {
        val mobile = p.numbers.filter { it.second == 2 }
        val n = if (mobile.size == 1) mobile[0] else p.numbers[0]
        return Pick(p.name, n.first, typeLabel(n.second))
    }

    fun resolve(c: Context, q0: String): Resolved {
        val q = q0.trim()
        if (q.isEmpty()) return Resolved.None
        if (q.count { it.isDigit() } >= 5 && q.none { it.isLetter() }) return Resolved.One(Pick(q, q))
        val al = Learned.alias(c, q)
        if (al != null) return Resolved.One(Pick(al.first.ifBlank { q }, al.second))

        val scored = all(c)
            .filter { it.numbers.isNotEmpty() }
            .map { Pair(it, Names.score(q, it.name)) }
            .filter { it.second >= 55 }
            .sortedByDescending { it.second }
        if (scored.isEmpty()) return Resolved.None

        val best = scored[0]
        val second = scored.getOrNull(1)
        val confident = best.second >= 80 && (second == null || best.second - second.second >= 8)
        if (confident) {
            val p = best.first
            val mobiles = p.numbers.filter { it.second == 2 }
            return if (p.numbers.size == 1 || mobiles.size == 1) {
                Resolved.One(bestOf(p))
            } else {
                Resolved.Many(q, picksOf(p), true)
            }
        }
        return Resolved.Many(q, scored.take(6).map { bestOf(it.first) }, false)
    }

    // true when the text clearly names exactly one contact (used to split "wa ali raza hello" correctly)
    fun isClear(c: Context, text: String): Boolean {
        val r = resolve(c, text)
        return r is Resolved.One
    }

    fun numberFor(c: Context, name: String): String? {
        val r = resolve(c, name)
        return if (r is Resolved.One) r.pick.number else null
    }

    // does a notification title / caller name refer to this friend (typed name, nickname or number)?
    fun sameAs(c: Context, friend: String, title: String): Boolean {
        val f = friend.trim()
        val t = title.trim()
        if (f.isEmpty() || t.isEmpty()) return false
        if (t.contains(f, true)) return true
        val fd = Learned.tail(f)
        if (f.none { it.isLetter() } && fd.length >= 6) return Learned.tail(t) == fd
        if (Names.score(f, t) >= 80) return true
        val al = Learned.alias(c, f)
        if (al != null) {
            if (Names.score(al.first, t) >= 80) return true
            if (t.none { it.isLetter() } && Learned.tail(t) == Learned.tail(al.second)) return true
        }
        val r = resolve(c, f)
        if (r is Resolved.One) {
            if (Names.score(r.pick.name, t) >= 85) return true
            if (t.none { it.isLetter() } && Learned.tail(t) == Learned.tail(r.pick.number)) return true
        }
        return false
    }
}
