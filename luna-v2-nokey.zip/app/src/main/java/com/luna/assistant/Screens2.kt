package com.luna.assistant

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

// ---------------------------------------------------------------- ACCESS
fun MainActivity.permList(): List<Triple<String, String, String>> {
    val l = mutableListOf(
        Triple("Microphone", Manifest.permission.RECORD_AUDIO, "Voice commands"),
        Triple("Contacts", Manifest.permission.READ_CONTACTS, "Find names and numbers"),
        Triple("Phone state", Manifest.permission.READ_PHONE_STATE, "Detect incoming calls"),
        Triple("Call log", Manifest.permission.READ_CALL_LOG, "See the caller's number"),
        Triple("Answer or end calls", Manifest.permission.ANSWER_PHONE_CALLS, "Pick up or reject calls"),
        Triple("Make calls", Manifest.permission.CALL_PHONE, "The \"call\" command"),
        Triple("Send SMS", Manifest.permission.SEND_SMS, "SMS replies and commands"),
        Triple("Read SMS", Manifest.permission.READ_SMS, "The \"read my last SMS\" command")
    )
    if (Build.VERSION.SDK_INT >= 33) {
        l.add(Triple("Notifications", "android.permission.POST_NOTIFICATIONS", "Scam alerts"))
    }
    return l
}

fun MainActivity.revoke(perms: List<String>) {
    try {
        if (Build.VERSION.SDK_INT >= 34) {
            revokeSelfPermissionsOnKill(perms)
        } else if (Build.VERSION.SDK_INT >= 33) {
            perms.forEach { revokeSelfPermissionOnKill(it) }
        }
    } catch (_: Exception) {
    }
    toast("To remove a permission, turn it off in App settings > Permissions.")
    appSettings()
}

fun MainActivity.specialRow(title: String, desc: String, on: Boolean, intent: () -> Intent): View {
    val t = tv(if (on) "On" else "Off", 13f, if (on) Pal.good else Pal.sub, 1)
    return settingRow(title, desc, t) { startActivity(intent()) }
}

fun MainActivity.accessView(): View {
    val a = this
    val v = ArrayList<View>()
    v.add(heading("Access", "Control what Luna may do, and keep an eye on your apps."))
    v.add(segmented(listOf("Permissions", "Apps"), accessSub) {
        accessSub = it
        show(3)
    })
    if (accessSub == 1) {
        appsList(v)
        return page(v)
    }

    v.add(label("Security mode"))
    val cur = Prefs.get(a, "mode", "MEDIUM")
    fun mode(id: String, t: String, s: String): View {
        val tick = if (cur == id) ic(R.drawable.ic_check, 20, Pal.accent) else View(a)
        return settingRow(t, s, tick) {
            Prefs.put(a, "mode", id)
            show(3)
        }
    }
    v.add(
        group(
            listOf(
                mode("LOW", "Ask every time", "Safest. Luna confirms every action."),
                mode("MEDIUM", "Balanced", "Confirms calls and messages only."),
                mode("HARD", "No confirmation", "Luna acts immediately. Use with care.")
            )
        )
    )

    v.add(label("Permissions"))
    val row = LinearLayout(a)
    row.addView(btn("Allow all", 1) {
        requestAll(permList().map { it.second })
    }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
    row.addView(btn("Remove all", 3) {
        revoke(permList().map { it.second }.filter { granted(it) })
    }, LinearLayout.LayoutParams(0, -2, 1f))
    v.add(row)
    v.add(group(permList().map { (name, perm, desc) ->
        settingRow(name, desc, sw(granted(perm)) { on ->
            if (on) {
                permQueue.clear()
                requestPermissions(arrayOf(perm), 11)
            } else {
                revoke(listOf(perm))
            }
        })
    }))

    v.add(label("Special access"))
    v.add(
        group(
            listOf(
                specialRow("Notification access", "Read friends' messages and auto-reply", listenerOn()) { Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) },
                specialRow("WhatsApp auto-send", "Presses Send for messages you ask for", WaSender.accessibilityOn(a)) { Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS) },
                specialRow("Display over other apps", "Lets background tasks open WhatsApp", Settings.canDrawOverlays(a)) {
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                },
                specialRow("Usage access", "Shows when each app was last used", usageOn()) { Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS) },
                specialRow("Modify system settings", "Needed for the brightness command", Settings.System.canWrite(a)) {
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                },
                specialRow("Battery", "Set to unrestricted so Luna stays alive", false) { Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
            )
        )
    )
    v.add(btn("Stop permission auto-reset (App info)", 1) { appSettings() })

    v.add(label("Scam guard"))
    v.add(group(listOf(settingRow("Scam message alerts", "Warns about risky messages and links", sw(Prefs.getBool(a, "scam_guard", true)) { Prefs.putBool(a, "scam_guard", it) }, R.drawable.ic_shield))))
    val out = tv("", 13f, Pal.sub)
    v.add(btn("Scan installed apps", 1, R.drawable.ic_refresh) { scanApps(out) })
    v.add(out)
    return page(v)
}

fun MainActivity.scanApps(out: TextView) {
    out.text = "Scanning..."
    Thread {
        val risky = listOf(
            "SEND_SMS", "READ_SMS", "RECEIVE_SMS", "RECORD_AUDIO", "READ_CONTACTS", "CAMERA",
            "SYSTEM_ALERT_WINDOW", "REQUEST_INSTALL_PACKAGES", "BIND_ACCESSIBILITY_SERVICE",
            "READ_CALL_LOG", "BIND_DEVICE_ADMIN", "ACCESS_FINE_LOCATION"
        )
        val res = mutableListOf<Pair<Int, String>>()
        for (r in loadApps()) {
            if (r.system || r.pkg == packageName) continue
            val n = r.perms.count { q -> risky.any { q.first.endsWith(it) } }
            if (n >= 4) res.add(Pair(n, r.label))
        }
        res.sortByDescending { it.first }
        val txt = if (res.isEmpty()) {
            "No suspicious apps found."
        } else {
            "These apps ask for many sensitive permissions. Remove any you don't need:\n\n" +
                res.take(15).joinToString("\n") { "\u2022 ${it.second} (${it.first} sensitive permissions)" }
        }
        runOnUiThread { out.text = txt }
    }.start()
}

fun MainActivity.ago(t: Long): String {
    if (t <= 0L) return "unknown"
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 60 -> "${m}m ago"
        m < 1440 -> "${m / 60}h ago"
        else -> "${m / 1440}d ago"
    }
}

fun MainActivity.appDialog(r: AppRow) {
    val sb = StringBuilder()
    sb.append(r.pkg).append("\n")
    sb.append("Last used: ").append(if (usageOn()) ago(r.lastUsed) else "turn on Usage access").append("\n\n")
    if (r.perms.isEmpty()) {
        sb.append("No permissions requested.")
    } else {
        r.perms.sortedByDescending { it.second }.forEach {
            sb.append(if (it.second) "\u2713  " else "\u2717  ").append(it.first.substringAfterLast('.')).append("\n")
        }
    }
    val b = AlertDialog.Builder(this)
        .setTitle(r.label)
        .setMessage(sb.toString())
        .setPositiveButton("App settings") { _, _ -> appSettings(r.pkg) }
        .setNeutralButton("Open app") { _, _ ->
            val li = packageManager.getLaunchIntentForPackage(r.pkg)
            if (li != null) startActivity(li) else toast("This app can't be opened")
        }
        .setNegativeButton("Close", null)
    showDialog(b)
}

fun MainActivity.appsList(v: MutableList<View>) {
    val a = this
    val search = edit("Search apps", "")
    v.add(search)
    var showSys = false
    val info = tv("Loading apps...", 12.5f, Pal.sub)
    val list = LinearLayout(a)
    list.orientation = LinearLayout.VERTICAL

    fun render() {
        val rows = appsCache ?: return
        val q = search.text.toString().trim().lowercase()
        val f = rows.filter { (showSys || !it.system) && (q.isEmpty() || it.label.lowercase().contains(q) || it.pkg.contains(q)) }
        list.removeAllViews()
        info.text = "Showing ${minOf(f.size, 100)} of ${f.size} apps"
        val items = f.take(100).map { r ->
            val gcount = r.perms.count { it.second }
            val iv = ImageView(a)
            try {
                iv.setImageDrawable(packageManager.getApplicationIcon(r.pkg))
            } catch (_: Exception) {
            }
            val row = settingRow(r.label, "$gcount of ${r.perms.size} permissions  \u00B7  used ${ago(r.lastUsed)}", null) { appDialog(r) }
            val ip = LinearLayout.LayoutParams(dp(36), dp(36))
            ip.rightMargin = dp(12)
            row.addView(iv, 0, ip)
            row
        }
        if (items.isNotEmpty()) list.addView(group(items))
    }

    v.add(group(listOf(settingRow("Show system apps", "", sw(false) {
        showSys = it
        render()
    }))))
    v.add(info)
    search.onChange { render() }
    v.add(list)
    if (appsCache != null) {
        render()
    } else {
        Thread {
            loadApps()
            runOnUiThread { if (current == 3 && accessSub == 1) render() }
        }.start()
    }
}

// ---------------------------------------------------------------- SETTINGS
fun MainActivity.memoryDialog(title: String, hint1: String, hint2: String, onOk: (String, String) -> Unit) {
    val a = this
    val e1 = edit(hint1, "")
    val e2 = edit(hint2, "")
    val box = LinearLayout(a)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(20), dp(8), dp(20), 0)
    box.addView(e1, lp(0, 8))
    box.addView(e2, lp(0, 4))
    val b = AlertDialog.Builder(a).setTitle(title).setView(box)
        .setPositiveButton("Save") { _, _ ->
            val x = e1.text.toString().trim()
            val y = e2.text.toString().trim()
            if (x.isNotEmpty() && y.isNotEmpty()) onOk(x, y)
        }
        .setNegativeButton("Cancel", null)
    showDialog(b)
}

fun MainActivity.settingsView(): View {
    val a = this
    val v = ArrayList<View>()
    v.add(heading("Settings"))

    // appearance
    v.add(label("Appearance"))
    val themes = listOf("system", "dark", "light")
    v.add(segmented(listOf("System", "Dark", "Light"), themes.indexOf(Prefs.get(a, "theme", "system")).coerceAtLeast(0)) {
        Prefs.put(a, "theme", themes[it])
        recreate()
    })

    // assistant
    v.add(label("Assistant"))
    val ac = card()
    ac.addView(prefEdit("Assistant name", "name", "Luna"), lp(0, 10))
    val nf = FlowLayout(a)
    nf.hGap = dp(8)
    nf.vGap = dp(8)
    listOf("Luna", "Friday", "Jarvis", "Nova").forEach { n ->
        nf.addView(chip(n) {
            Prefs.put(a, "name", n)
            show(4)
        })
    }
    ac.addView(nf)
    v.add(ac)

    // AI
    v.add(label("AI provider"))
    val p = AiClient.current(a)
    val pc = card()
    pc.addView(settingRow("Provider", p.label, ic(R.drawable.ic_chevron, 18, Pal.sub)) {
        val b = AlertDialog.Builder(a).setTitle("AI provider")
            .setItems(AiClient.providers.map { it.label }.toTypedArray()) { _, which ->
                Prefs.put(a, "provider", AiClient.providers[which].id)
                show(4)
            }
        showDialog(b)
    }, lp(0, 8))
    pc.addView(prefEdit("API key", "key_" + p.id, "", 1, true), lp(0, 8))
    val model = prefEdit("Model", "model_" + p.id, p.model)
    pc.addView(model, lp(0, 8))
    if (p.id == "custom") pc.addView(prefEdit("API URL (OpenAI compatible, ends with /chat/completions)", "custom_url"), lp(0, 8))
    if (p.id == "claude") {
        pc.addView(prefEdit("Workspace ID (only if you see a workspace error)", "ws_claude"), lp(0, 8))
    }
    val br = LinearLayout(a)
    br.addView(btn("Find models", 1, R.drawable.ic_refresh) {
        val key = Prefs.get(a, "key_" + p.id).trim()
        if (key.isEmpty()) {
            toast("Add your API key first.")
        } else {
            toast("Looking up models...")
            Thread {
                val res: List<String>? = try {
                    AiClient.listModels(a, p, key)
                } catch (e: Exception) {
                    null
                }
                runOnUiThread {
                    if (res == null || res.isEmpty()) {
                        toast("Couldn't load the model list. Check your key" + (if (p.id == "claude") " and Workspace ID." else "."))
                    } else {
                        val b = AlertDialog.Builder(a).setTitle("Choose a model")
                            .setItems(res.take(60).toTypedArray()) { _, which ->
                                Prefs.put(a, "model_" + p.id, res[which])
                                show(4)
                            }
                        showDialog(b)
                    }
                }
            }.start()
        }
    }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
    br.addView(btn("Test", 0) {
        toast("Testing...")
        Thread {
            val r = AiClient.chat(a, listOf(Pair("user", "Say hi in one short line.")), "Be brief.")
            runOnUiThread {
                showDialog(AlertDialog.Builder(a).setTitle(if (r.ok) "It works" else "Problem").setMessage(r.text).setPositiveButton("OK", null))
            }
        }.start()
    }, LinearLayout.LayoutParams(0, -2, 1f))
    pc.addView(br)
    v.add(pc)

    // language and voice
    v.add(label("Language and voice"))
    val curTag = Prefs.get(a, "lang", "en-US")
    val curLang = Langs.list.firstOrNull { it.second == curTag }?.first ?: "English (US)"
    val voices = Speaker.voicesFor(a)
    val curVoice = Prefs.get(a, "voice")
    v.add(
        group(
            listOf(
                settingRow("Language", curLang, ic(R.drawable.ic_chevron, 18, Pal.sub)) {
                    val b = AlertDialog.Builder(a).setTitle("Language")
                        .setItems(Langs.list.map { it.first }.toTypedArray()) { _, which ->
                            Prefs.put(a, "lang", Langs.list[which].second)
                            Prefs.put(a, "voice", "")
                            lang = L.code(Langs.list[which].second)
                            Speaker.applyPrefs(a)
                            show(4)
                        }
                    showDialog(b)
                },
                settingRow("Voice", if (curVoice.isBlank()) "Default" else curVoice, ic(R.drawable.ic_chevron, 18, Pal.sub)) {
                    val names = listOf("Default voice") + voices.mapIndexed { i, vo -> "Voice ${i + 1}  \u00B7  ${vo.name}" }
                    val b = AlertDialog.Builder(a).setTitle("Voice")
                        .setItems(names.toTypedArray()) { _, which ->
                            Prefs.put(a, "voice", if (which == 0) "" else voices[which - 1].name)
                            Speaker.applyPrefs(a)
                            Speaker.speak(a, "Hello, I'm " + Prefs.get(a, "name", "Luna") + ".")
                            show(4)
                        }
                    showDialog(b)
                },
                settingRow("Speak replies aloud", "", sw(Prefs.getBool(a, "speak", true)) { Prefs.putBool(a, "speak", it) })
            )
        )
    )
    val note = tv("Luna answers in English by default and switches to whatever language you speak or write. For more voices: Phone Settings > Text-to-speech.", 12f, Pal.sub)
    note.setPadding(dp(4), 0, 0, 0)
    v.add(note)

    // behaviour
    v.add(label("Messaging"))
    val mc = card()
    mc.addView(tv("When you say \"message Ali ...\"", 13.5f, Pal.sub), lp(0, 8))
    val apps = listOf("wa", "sms")
    mc.addView(segmented(listOf("WhatsApp", "SMS"), apps.indexOf(Prefs.get(a, "msg_app", "wa")).coerceAtLeast(0)) {
        Prefs.put(a, "msg_app", apps[it])
        show(4)
    }, lp(0, 10))
    mc.addView(prefEdit("Default country code for numbers without +, e.g. 92 or 91", "cc"))
    v.add(mc)

    // memory
    val entries = Learned.list(a)
    v.add(label("What Luna remembers  \u00B7  ${entries.size}"))
    val mem = LinearLayout(a)
    mem.orientation = LinearLayout.VERTICAL
    if (entries.isEmpty()) {
        v.add(tv("Names, nicknames and numbers Luna learns will show up here. They stay saved even if you remove the Contacts permission.", 13f, Pal.sub))
    } else {
        v.add(group(entries.take(80).map { e ->
            val del = iconBtn(R.drawable.ic_trash, Pal.sub, 0, 40) {
                Learned.forgetEntry(a, e)
                show(4)
            }
            settingRow(e.title, e.detail, del)
        }))
    }
    val mr = LinearLayout(a)
    mr.addView(btn("Add a nickname", 1, R.drawable.ic_plus) {
        memoryDialog("Add a nickname", "Nickname, e.g. bro", "Contact name or number") { x, y ->
            runCmd(Cmd("learnalias", x, y))
            handler.postDelayed({ show(4) }, 400)
        }
    }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
    mr.addView(btn("Save a number", 1, R.drawable.ic_plus) {
        memoryDialog("Save a number", "Name", "Number, e.g. +92 300 1234567") { x, y ->
            runCmd(Cmd("learnnum", x, y))
            handler.postDelayed({ show(4) }, 400)
        }
    }, LinearLayout.LayoutParams(0, -2, 1f))
    v.add(mr)

    // about
    v.add(label("About"))
    val about = tv("Luna 2.0\nAPI keys are stored only on this phone and sent only to the provider you choose. Replies and tool results are never shared with anyone else.", 12.5f, Pal.sub)
    about.gravity = Gravity.START
    v.add(about)
    return page(v)
}
