package com.luna.assistant

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

object Pal {
    var dark = true
    var bg = 0
    var surface = 0
    var surface2 = 0
    var line = 0
    var text = 0
    var sub = 0
    var accent = 0
    var onAccent = 0
    var danger = 0
    var good = 0
    var warn = 0
    var bubbleMe = 0
    var bubbleMeText = 0
    var ripple = 0

    fun alpha(color: Int, a: Float): Int = (color and 0x00FFFFFF) or ((a * 255).toInt() shl 24)

    fun apply(d: Boolean) {
        dark = d
        if (d) {
            bg = 0xFF0E1114.toInt()
            surface = 0xFF171B20.toInt()
            surface2 = 0xFF1F242B.toInt()
            line = 0xFF2A3038.toInt()
            text = 0xFFECEFF2.toInt()
            sub = 0xFF8F99A5.toInt()
            accent = 0xFF3DC9B0.toInt()
            onAccent = 0xFF04201B.toInt()
            danger = 0xFFFF7A7A.toInt()
            good = 0xFF4FD08F.toInt()
            warn = 0xFFF2B84B.toInt()
            bubbleMe = 0xFF1C6B5F.toInt()
            bubbleMeText = 0xFFFFFFFF.toInt()
            ripple = 0x22FFFFFF
        } else {
            bg = 0xFFF4F5F7.toInt()
            surface = 0xFFFFFFFF.toInt()
            surface2 = 0xFFEEF0F3.toInt()
            line = 0xFFE0E3E8.toInt()
            text = 0xFF14181C.toInt()
            sub = 0xFF66707C.toInt()
            accent = 0xFF0F8F7C.toInt()
            onAccent = 0xFFFFFFFF.toInt()
            danger = 0xFFD64545.toInt()
            good = 0xFF1E9E63.toInt()
            warn = 0xFFB87A00.toInt()
            bubbleMe = 0xFF0F8F7C.toInt()
            bubbleMeText = 0xFFFFFFFF.toInt()
            ripple = 0x1A000000
        }
    }
}

fun Context.dp(x: Int): Int = (x * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rr(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(r).toFloat()
    if (stroke != 0) g.setStroke(dp(1), stroke)
    return g
}

fun Context.corners(color: Int, tl: Int, tr: Int, br: Int, bl: Int, stroke: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    val a = dp(tl).toFloat()
    val b = dp(tr).toFloat()
    val c = dp(br).toFloat()
    val d = dp(bl).toFloat()
    g.cornerRadii = floatArrayOf(a, a, b, b, c, c, d, d)
    if (stroke != 0) g.setStroke(dp(1), stroke)
    return g
}

fun Context.ripple(content: Drawable, r: Int): Drawable {
    val mask = GradientDrawable()
    mask.setColor(Color.WHITE)
    mask.cornerRadius = dp(r).toFloat()
    return RippleDrawable(ColorStateList.valueOf(Pal.ripple), content, mask)
}

fun Context.tv(t: String, size: Float = 15f, color: Int = Pal.text, w: Int = 0): TextView {
    val v = TextView(this)
    v.text = t
    v.textSize = size
    v.setTextColor(color)
    if (w == 1) v.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    if (w == 2) v.typeface = Typeface.DEFAULT_BOLD
    return v
}

fun Context.ic(res: Int, sizeDp: Int = 24, tint: Int = Pal.text): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.imageTintList = ColorStateList.valueOf(tint)
    v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    return v
}

fun Context.iconBtn(res: Int, tint: Int = Pal.text, bg: Int = 0, sizeDp: Int = 44, onClick: () -> Unit): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.imageTintList = ColorStateList.valueOf(tint)
    val pad = dp(sizeDp / 4 + 1)
    v.setPadding(pad, pad, pad, pad)
    v.background = ripple(rr(bg, sizeDp), sizeDp)
    v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    v.isClickable = true
    v.setOnClickListener { onClick() }
    return v
}

// style: 0 filled, 1 tonal, 2 text, 3 danger
fun Context.btn(t: String, style: Int = 0, icon: Int = 0, onClick: () -> Unit): TextView {
    val v = TextView(this)
    v.text = t
    v.gravity = Gravity.CENTER
    v.textSize = 14.5f
    v.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val fg = when (style) {
        0 -> Pal.onAccent
        1 -> Pal.text
        3 -> Pal.danger
        else -> Pal.accent
    }
    val bgc = when (style) {
        0 -> Pal.accent
        1 -> Pal.surface2
        3 -> Pal.alpha(Pal.danger, 0.12f)
        else -> 0
    }
    v.setTextColor(fg)
    v.background = ripple(rr(bgc, 14, if (style == 1) Pal.line else 0), 14)
    v.setPadding(dp(18), dp(12), dp(18), dp(12))
    v.minHeight = dp(46)
    if (icon != 0) {
        val d = getDrawable(icon)
        if (d != null) {
            val m = d.mutate()
            m.setTint(fg)
            m.setBounds(0, 0, dp(18), dp(18))
            v.setCompoundDrawables(m, null, null, null)
            v.compoundDrawablePadding = dp(8)
        }
    }
    v.isClickable = true
    v.setOnClickListener { onClick() }
    return v
}

fun Context.chip(t: String, onClick: () -> Unit): TextView {
    val v = TextView(this)
    v.text = t
    v.textSize = 13.5f
    v.setTextColor(Pal.text)
    v.setPadding(dp(14), dp(8), dp(14), dp(8))
    v.background = ripple(rr(Pal.surface, 18, Pal.line), 18)
    v.isClickable = true
    v.setOnClickListener { onClick() }
    return v
}

fun Context.edit(hint: String, value: String, lines: Int = 1): EditText {
    val e = EditText(this)
    e.hint = hint
    e.setText(value)
    e.textSize = 15f
    e.setTextColor(Pal.text)
    e.setHintTextColor(Pal.sub)
    e.background = rr(Pal.surface2, 12, Pal.line)
    e.setPadding(dp(14), dp(12), dp(14), dp(12))
    if (lines > 1) {
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        e.minLines = lines
        e.gravity = Gravity.TOP or Gravity.START
    } else {
        e.setSingleLine(true)
    }
    return e
}

fun Context.sw(checked: Boolean, onChange: (Boolean) -> Unit): Switch {
    val s = Switch(this)
    s.isChecked = checked
    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
    s.thumbTintList = ColorStateList(states, intArrayOf(Pal.accent, Pal.sub))
    s.trackTintList = ColorStateList(states, intArrayOf(Pal.alpha(Pal.accent, 0.4f), Pal.alpha(Pal.sub, 0.3f)))
    s.setOnCheckedChangeListener { _, v -> onChange(v) }
    return s
}

fun Context.lp(top: Int = 0, bottom: Int = 10): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(-1, -2)
    p.topMargin = dp(top)
    p.bottomMargin = dp(bottom)
    return p
}

fun Context.toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

fun Context.divider(inset: Int = 0): View {
    val v = View(this)
    v.setBackgroundColor(Pal.line)
    val p = LinearLayout.LayoutParams(-1, 1)
    p.leftMargin = dp(inset)
    v.layoutParams = p
    return v
}

fun Context.label(t: String): TextView {
    val v = tv(t.uppercase(), 11.5f, Pal.sub, 1)
    v.letterSpacing = 0.08f
    v.setPadding(dp(4), dp(10), 0, dp(2))
    return v
}

fun Context.heading(t: String, sub: String = ""): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.addView(tv(t, 26f, Pal.text, 1))
    if (sub.isNotBlank()) {
        val s = tv(sub, 13.5f, Pal.sub)
        s.setPadding(0, dp(4), 0, 0)
        c.addView(s)
    }
    return c
}

// a rounded group of rows with hairline dividers
fun Context.group(rows: List<View>): LinearLayout {
    val g = LinearLayout(this)
    g.orientation = LinearLayout.VERTICAL
    g.background = rr(Pal.surface, 18, Pal.line)
    g.clipToOutline = true
    rows.forEachIndexed { i, r ->
        if (i > 0) g.addView(divider(14))
        g.addView(r, LinearLayout.LayoutParams(-1, -2))
    }
    return g
}

fun Context.card(): LinearLayout {
    val g = LinearLayout(this)
    g.orientation = LinearLayout.VERTICAL
    g.background = rr(Pal.surface, 18, Pal.line)
    g.setPadding(dp(16), dp(16), dp(16), dp(16))
    return g
}

fun Context.settingRow(title: String, sub: String = "", trailing: View? = null, icon: Int = 0, onClick: (() -> Unit)? = null): LinearLayout {
    val r = LinearLayout(this)
    r.orientation = LinearLayout.HORIZONTAL
    r.gravity = Gravity.CENTER_VERTICAL
    r.setPadding(dp(14), dp(12), dp(14), dp(12))
    if (icon != 0) {
        val b = FrameLayout(this)
        b.background = rr(Pal.alpha(Pal.accent, 0.14f), 12)
        val i = ic(icon, 20, Pal.accent)
        b.addView(i, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        val bp = LinearLayout.LayoutParams(dp(40), dp(40))
        bp.rightMargin = dp(12)
        r.addView(b, bp)
    }
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.addView(tv(title, 15f, Pal.text, 1))
    if (sub.isNotBlank()) {
        val s = tv(sub, 12.5f, Pal.sub)
        s.setPadding(0, dp(2), 0, 0)
        col.addView(s)
    }
    r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
    if (trailing != null) {
        val tp = LinearLayout.LayoutParams(-2, -2)
        tp.leftMargin = dp(10)
        r.addView(trailing, tp)
    }
    if (onClick != null) {
        r.background = ripple(ColorDrawable(0), 0)
        r.isClickable = true
        r.setOnClickListener { onClick() }
    }
    return r
}

fun Context.segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.background = rr(Pal.surface2, 14, Pal.line)
    row.setPadding(dp(3), dp(3), dp(3), dp(3))
    options.forEachIndexed { i, o ->
        val t = tv(o, 13.5f, if (i == selected) Pal.accent else Pal.sub, 1)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(6), dp(9), dp(6), dp(9))
        if (i == selected) t.background = rr(Pal.alpha(Pal.accent, 0.18f), 11)
        t.isClickable = true
        t.setOnClickListener { onSelect(i) }
        row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
    }
    return row
}

fun Context.page(views: List<View>): ScrollView {
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(16), dp(20), dp(16), dp(28))
    views.forEach { col.addView(it, lp(0, 12)) }
    val s = ScrollView(this)
    s.overScrollMode = View.OVER_SCROLL_NEVER
    s.isVerticalScrollBarEnabled = false
    s.addView(col)
    return s
}

fun Context.showDialog(b: AlertDialog.Builder): AlertDialog {
    val d = b.create()
    d.show()
    d.window?.setBackgroundDrawable(rr(Pal.surface, 22))
    d.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Pal.accent)
    d.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Pal.sub)
    d.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(Pal.accent)
    return d
}
