package com.luna.assistant

import android.content.Context
import org.json.JSONObject

// Permanent memory for names and numbers. Once Luna has seen a name <-> number pair (from your contacts,
// a call, a message, or because you told her), she keeps it, even if the Contacts permission is removed later.
object Learned {
    private const val K_ALIAS = "learn_alias"
    private const val K_PAIRS = "learn_pairs"
    private const val CAP = 600

    class Entry(val kind: String, val key: String, val title: String, val detail: String)

    fun digits(n: String): String = n.filter { it.isDigit() }

    fun tail(n: String): String {
        val d = digits(n)
        return if (d.length > 9) d.takeLast(9) else d
    }

    private fun load(c: Context, k: String): JSONObject =
        try {
            JSONObject(Prefs.get(c, k, "{}"))
        } catch (_: Exception) {
            JSONObject()
        }

    private fun save(c: Context, k: String, o: JSONObject) {
        while (o.length() > CAP) {
            val first = o.keys().next()
            o.remove(first)
        }
        Prefs.put(c, k, o.toString())
    }

    // nickname / short form -> (contact name, number)
    fun alias(c: Context, spoken: String): Pair<String, String>? {
        val o = load(c, K_ALIAS).optJSONObject(Names.key(spoken)) ?: return null
        val p = o.optString("p")
        if (p.isBlank()) return null
        return Pair(o.optString("n"), p)
    }

    fun teachAlias(c: Context, spoken: String, name: String, number: String) {
        val k = Names.key(spoken)
        if (k.isBlank() || digits(number).length < 5) return
        val all = load(c, K_ALIAS)
        all.remove(k)
        all.put(k, JSONObject().put("s", spoken.trim()).put("n", name).put("p", number))
        save(c, K_ALIAS, all)
        remember(c, name, number)
        Contacts.invalidate()
    }

    fun remember(c: Context, name: String, number: String) {
        val nm = name.trim()
        if (nm.isBlank() || digits(number).length < 5 || digits(nm).length >= 5) return
        val k = Names.key(nm)
        if (k.isBlank()) return
        val all = load(c, K_PAIRS)
        val old = all.optJSONObject(k)
        if (old != null && tail(old.optString("p")) == tail(number)) return
        all.remove(k)
        all.put(k, JSONObject().put("n", nm).put("p", number))
        save(c, K_PAIRS, all)
        Contacts.invalidate()
    }

    fun pairs(c: Context): List<Pair<String, String>> {
        val o = load(c, K_PAIRS)
        val out = ArrayList<Pair<String, String>>()
        val it = o.keys()
        while (it.hasNext()) {
            val e = o.optJSONObject(it.next()) ?: continue
            out.add(Pair(e.optString("n"), e.optString("p")))
        }
        return out
    }

    fun nameForNumber(c: Context, number: String): String? {
        val t = tail(number)
        if (t.length < 5) return null
        return pairs(c).firstOrNull { tail(it.second) == t }?.first
    }

    fun numberForName(c: Context, name: String): String? {
        val e = load(c, K_PAIRS).optJSONObject(Names.key(name)) ?: return null
        return e.optString("p").ifBlank { null }
    }

    fun list(c: Context): List<Entry> {
        val out = ArrayList<Entry>()
        val a = load(c, K_ALIAS)
        val ai = a.keys()
        while (ai.hasNext()) {
            val k = ai.next()
            val e = a.optJSONObject(k) ?: continue
            out.add(Entry("alias", k, "\"" + e.optString("s") + "\"  \u2192  " + e.optString("n"), e.optString("p")))
        }
        val p = load(c, K_PAIRS)
        val pi = p.keys()
        while (pi.hasNext()) {
            val k = pi.next()
            val e = p.optJSONObject(k) ?: continue
            out.add(Entry("pair", k, e.optString("n"), e.optString("p")))
        }
        return out
    }

    fun forgetEntry(c: Context, e: Entry) {
        val k = if (e.kind == "alias") K_ALIAS else K_PAIRS
        val o = load(c, k)
        o.remove(e.key)
        save(c, k, o)
        Contacts.invalidate()
    }

    // "forget bro" -> removes nickname and remembered number with that name
    fun forgetText(c: Context, text: String): Int {
        val key = Names.key(text)
        var n = 0
        for (k in listOf(K_ALIAS, K_PAIRS)) {
            val o = load(c, k)
            if (o.has(key)) {
                o.remove(key)
                save(c, k, o)
                n++
            }
        }
        Contacts.invalidate()
        return n
    }

    fun count(c: Context): Int = load(c, K_ALIAS).length() + load(c, K_PAIRS).length()
}
