package com.luna.assistant

import android.content.Context

data class Cmd(val kind: String, val a: String = "", val b: String = "", val c: String = "")

// Understands typed or spoken commands without the AI: English, Hinglish / Roman Urdu, Hindi and Urdu script.
// Anything it does not recognise is passed to the AI, which can use the same actions.
object Commands {
    private const val DO = "(?:kar\\s*do|kardo|krdo|kr\\s*do|karo|kro|kar|kr|karna|kijiye|kijiye|karen|de|do|dena)"
    private val msgWord = "whatsapp|whats\\s*app|watsapp|whatsap|wa|sms|text|msg|message|massage"
    private val openStart = "open|launch|start|kholo|khol|खोलो|खोल|کھولو|کھول|chalu\\s+karo|chalao|chala"
    private val openEnd = "kholo|khol\\s*do|khol\\s*de|khol|open\\s*karo|open\\s*kro|open\\s*kar\\s*do|chalu\\s*karo|chalu\\s*kro|chalao|chala\\s*do|खोलो|खोल\\s*दो|کھولو|کھول\\s*دو"
    private val domain = Regex(
        "^(?:open\\s+|go\\s+to\\s+|visit\\s+)?((?:https?://)?[a-z0-9-]+(?:\\.[a-z0-9-]+)*\\.(?:com|net|org|io|co|pk|in|app|dev|edu|gov|info|me|tv|ai|xyz)(?:/\\S*)?)$"
    )

    private fun prepare(c: Context, raw: String): String {
        var s = raw.trim().replace(Regex("\\s+"), " ")
        s = s.trimEnd('?', '!', '.', ' ', '\u0964')
        val name = Regex.escape(Prefs.get(c, "name", "Luna").lowercase())
        val lead = Regex("^(?:(?:hey|hi|hello|ok|okay|please|plz|pls|zara|jara|yaar|assistant|friday|jarvis|luna|nova|$name)[ ,]+)+", RegexOption.IGNORE_CASE)
        s = s.replace(lead, "")
        return s.trim()
    }

    // splits "ali raza hello how are you" into ("ali raza", "hello how are you")
    private fun splitNameMsg(c: Context, rest0: String): Pair<String, String> {
        val rest = rest0.trim()
        val d = Regex("^(.{1,40}?)\\s*(?::|\\s(?:ke|ki|ko|that|saying|ye)\\s)\\s*(.+)$", RegexOption.IGNORE_CASE).find(rest)
        if (d != null && d.groupValues[1].trim().split(" ").size <= 3) {
            return Pair(d.groupValues[1].trim(), d.groupValues[2].trim())
        }
        val tk = rest.split(" ").filter { it.isNotBlank() }
        if (tk.size <= 1) return Pair(rest, "")
        var n = minOf(3, tk.size - 1)
        while (n >= 2) {
            val nm = tk.take(n).joinToString(" ")
            if (Contacts.isClear(c, nm)) return Pair(nm, tk.drop(n).joinToString(" "))
            n--
        }
        return Pair(tk[0], tk.drop(1).joinToString(" "))
    }

    private fun msgKind(c: Context, w: String): String {
        val x = w.lowercase().replace(" ", "")
        return when {
            x == "sms" || x == "text" -> "sms"
            x.startsWith("wh") || x == "wa" -> "wamsg"
            else -> if (Prefs.get(c, "msg_app", "wa") == "sms") "sms" else "wamsg"
        }
    }

    fun parse(c: Context, raw: String): Cmd? {
        val s = prepare(c, raw)
        if (s.isEmpty()) return null
        val l = s.lowercase()
        val words = l.split(" ").size

        // ----- messaging (checked first so message text is kept untouched) -----
        val guard = Regex("^(?:$msgWord)(?:\\s+business)?\\s+(?:$openEnd|$openStart)$", RegexOption.IGNORE_CASE)
        if (!guard.containsMatchIn(l)) {
            Regex("^(?:send\\s+)?(?:a\\s+)?($msgWord)\\s+(?:message\\s+|msg\\s+)?(?:to\\s+)?(.+)$", RegexOption.IGNORE_CASE).find(s)?.let {
                val (nm, msg) = splitNameMsg(c, it.groupValues[2])
                if (nm.isNotBlank() && !nm.lowercase().matches(Regex(openEnd))) return Cmd(msgKind(c, it.groupValues[1]), nm, msg)
            }
        }
        Regex("^(.+?)\\s+(?:ko|को|کو)\\s+($msgWord)\\s*(?:$DO|bhej|bhejo|bhej\\s*do|send)?\\s*(?:ke|ki|ka|that|saying|:|-)?\\s*(.*)$", RegexOption.IGNORE_CASE).find(s)?.let {
            if (words <= 40) return Cmd(msgKind(c, it.groupValues[2]), it.groupValues[1].trim(), it.groupValues[3].trim())
        }
        Regex("^(.+?)\\s+(?:ko|को|کو)\\s+(?:bol|bolo|keh|kaho|bata|batao)\\s*(?:do|dena|de)?\\s*(?:ke|ki|ye|that)\\s+(.+)$", RegexOption.IGNORE_CASE).find(s)?.let {
            return Cmd(msgKind(c, "msg"), it.groupValues[1].trim(), it.groupValues[2].trim())
        }
        Regex("^(?:tell|inform|let)\\s+(.+?)\\s+(?:know\\s+)?(?:that\\s+)(.+)$", RegexOption.IGNORE_CASE).find(s)?.let {
            return Cmd(msgKind(c, "msg"), it.groupValues[1].trim(), it.groupValues[2].trim())
        }

        // ----- teach / recall / forget -----
        Regex("^(?:save|remember|add|yaad\\s*rakh(?:o)?)\\s+(.+?)\\s+(?:number\\s+|no\\.?\\s+|ka\\s+number\\s+|as\\s+|is\\s+)?(\\+?\\d[\\d\\s-]{6,})$", RegexOption.IGNORE_CASE).find(s)
            ?.let { return Cmd("learnnum", it.groupValues[1].trim(), it.groupValues[2].trim()) }
        Regex("^(.+?)\\s+(?:ka\\s+|ki\\s+)?(?:number|no|num)\\s+(?:is\\s+|hai\\s+)?(\\+?\\d[\\d\\s-]{6,})(?:\\s+(?:hai|h))?$", RegexOption.IGNORE_CASE).find(s)
            ?.let { return Cmd("learnnum", it.groupValues[1].trim(), it.groupValues[2].trim()) }
        Regex("^(?:remember|yaad\\s*rakh(?:o)?|note|learn)\\s+(?:that\\s+)?(.+?)\\s+(?:is|means|matlab|ka\\s+matlab|=)\\s+(.+)$", RegexOption.IGNORE_CASE).find(s)
            ?.let { return Cmd("learnalias", it.groupValues[1].trim(), it.groupValues[2].trim()) }
        if (words <= 6) {
            Regex("^(.+?)\\s+(?:matlab|ka\\s+matlab|means)\\s+(.+?)(?:\\s+hai)?$", RegexOption.IGNORE_CASE).find(s)
                ?.let { return Cmd("learnalias", it.groupValues[1].trim(), it.groupValues[2].trim()) }
        }
        Regex("^(?:number\\s+of|num\\s+of|number\\s+for)\\s+(.+)$", RegexOption.IGNORE_CASE).find(s)
            ?.let { return Cmd("shownum", it.groupValues[1].trim()) }
        Regex("^(?:what(?:'s|\\s+is)\\s+)?(.+?)(?:'s|\\s+ka|\\s+ki)\\s+(?:number|no|num)(?:\\s+(?:kya\\s+hai|batao|bata|dikhao|dikha|please))?$", RegexOption.IGNORE_CASE).find(s)
            ?.let { return Cmd("shownum", it.groupValues[1].trim()) }
        Regex("^(?:forget|bhool\\s*ja|bhul\\s*ja)\\s*(?:o|na)?\\s+(.+)$", RegexOption.IGNORE_CASE).find(s)
            ?.let { return Cmd("forget", it.groupValues[1].trim()) }

        // ----- websites -----
        domain.find(l)?.let {
            val u = it.groupValues[1]
            return Cmd("url", if (u.startsWith("http")) u else "https://$u")
        }

        if (l.startsWith("busy")) {
            return Cmd("busy", if (l.contains("off") || l.contains("band") || l.contains("stop")) "off" else "on")
        }
        if (words <= 7 && Regex("torch|flash\\s*light|tourch|टॉर्च|ٹارچ").containsMatchIn(l)) {
            return Cmd("torch", if (Regex("\\boff\\b|band|bujha|bujhao|बंद|بند|close|stop").containsMatchIn(l)) "off" else "on")
        }

        // ----- volume / brightness -----
        Regex("^(?:volume|vol|awaz|aawaz|sound|आवाज़|आवाज)\\s*(?:to|set|$DO)?\\s*(up|down|max|full|mute|low|badha|badhao|zyada|kam|\\d{1,3})\\s*%?$").find(l)?.let {
            val v = it.groupValues[1]
            val vv = if (v == "badha" || v == "badhao" || v == "zyada") "up" else if (v == "kam") "down" else v
            return Cmd("volume", vv)
        }
        if (Regex("^(?:increase|raise|turn up|volume badha\\w*)(?:\\s+(?:the\\s+)?volume)?$").matches(l)) return Cmd("volume", "up")
        if (Regex("^(?:decrease|lower|reduce|turn down)(?:\\s+(?:the\\s+)?volume)?$").matches(l)) return Cmd("volume", "down")
        if (l == "mute" || l == "silent" || l == "unmute") return Cmd("volume", if (l == "unmute") "50" else "mute")
        Regex("^(?:screen\\s+)?brightness\\s*(?:to|set|$DO)?\\s*(\\d{1,3}|max|full|low|min)\\s*%?$").find(l)?.let {
            val v = it.groupValues[1]
            val bv = if (v == "max" || v == "full") "100" else if (v == "low" || v == "min") "10" else v
            return Cmd("brightness", bv)
        }

        // ----- alarm / timer / info -----
        if (words <= 9 && l.contains("alarm") && !l.contains("cancel")) {
            Regex("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|a\\.m\\.?|p\\.m\\.?)?").find(l)?.let { m ->
                var h = m.groupValues[1].toInt()
                val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
                val ap = m.groupValues[3].replace(".", "")
                val pm = ap == "pm" || (ap.isEmpty() && Regex("shaam|sham|raat|rat|evening|night|dopahar|afternoon").containsMatchIn(l))
                if (pm && h < 12) h += 12
                if (ap == "am" && h == 12) h = 0
                if (h in 0..23 && mi in 0..59) return Cmd("alarm", "$h:$mi")
            }
        }
        if (words <= 8 && l.contains("timer")) {
            Regex("(\\d+)\\s*(sec\\w*|min\\w*|minat|hour\\w*|hr\\w*|ghant\\w*)?").find(l)?.let { m ->
                val n = m.groupValues[1].toInt()
                val u = m.groupValues[2]
                val secs = when {
                    u.startsWith("h") || u.startsWith("g") -> n * 3600
                    u.startsWith("s") -> n
                    else -> n * 60
                }
                return Cmd("timer", secs.toString())
            }
        }
        if (words <= 5 && l.contains("battery")) return Cmd("battery")
        if (words <= 4 && (l == "time" || l == "date" || l.contains("what time") || l.contains("time kya") || l.contains("today's date") || l.contains("aaj ki date"))) {
            return Cmd("time")
        }
        if (Regex("^(?:read|show|check)\\s+(?:my\\s+)?(?:last\\s+|latest\\s+|new\\s+)?(?:sms|message|messages|msg)$").matches(l)) return Cmd("readsms")
        Regex("^(wifi|bluetooth|location|display|sound)(?:\\s+settings?)?$").find(l)?.let { return Cmd("settings", it.groupValues[1]) }

        // ----- connectors -----
        Regex("^(?:weather|mausam|mosam|temperature|forecast)(?:\\s+(?:in|at|of|for|ka|ki))?\\s*(.*)$").find(l)?.let { return Cmd("weather", it.groupValues[1].trim()) }
        Regex("^(.+?)\\s+(?:ka|ki|me|mein)\\s+(?:weather|mausam|mosam)(?:\\s+(?:kaisa|kya)\\s*\\w*)?$").find(l)?.let { return Cmd("weather", it.groupValues[1].trim()) }
        Regex("^(?:news|khabrein|khabren|headlines|latest news)(?:\\s+(?:about|on|of|for|ki|ka))?\\s*(.*)$").find(l)?.let { return Cmd("news", it.groupValues[1].trim()) }
        Regex("^(?:convert\\s+)?(\\d+(?:\\.\\d+)?)\\s*([a-z]{3})\\s+(?:to|in|into|ko)\\s+([a-z]{3})$").find(l)?.let {
            return Cmd("fx", it.groupValues[1], it.groupValues[2].uppercase(), it.groupValues[3].uppercase())
        }

        // ----- calls -----
        if (words <= 8) {
            Regex("^(?:call|phone|dial|ring|کال|कॉल)\\s+(?:to\\s+)?(.+)$").find(l)?.let { return Cmd("call", cleanCallName(it.groupValues[1])) }
            Regex("^(?:call|phone)\\s+(?:laga|lagao|lga|kar|karo|kro)\\s+(.+)$").find(l)?.let { return Cmd("call", cleanCallName(it.groupValues[1])) }
            Regex("^(.+?)\\s+(?:ko|को|کو)\\s+(?:call|phone|कॉल|کال|fone|fon)\\b.*$").find(l)?.let { return Cmd("call", cleanCallName(it.groupValues[1])) }
            Regex("^(.+?)\\s+se\\s+(?:baat|bat|baatcheet)\\b.*$").find(l)?.let { return Cmd("call", cleanCallName(it.groupValues[1])) }
        }

        // ----- open an app -----
        if (words <= 6) {
            Regex("^(?:$openStart)\\s+(.+)$").find(l)?.let { return Cmd("open", it.groupValues[1].replace(Regex("\\s+app$"), "").trim()) }
            Regex("^(.+?)\\s+(?:$openEnd)$").find(l)?.let { return Cmd("open", it.groupValues[1].replace(Regex("\\s+app$"), "").trim()) }
        }

        // ----- web / media / maps -----
        Regex("^(?:navigate|directions?|route)\\s+(?:to\\s+)?(.+)$").find(l)?.let { return Cmd("navigate", it.groupValues[1]) }
        Regex("^take me to\\s+(.+)$").find(l)?.let { return Cmd("navigate", it.groupValues[1]) }
        Regex("^play\\s+(.+?)\\s+on\\s+spotify$").find(l)?.let { return Cmd("url", "https://open.spotify.com/search/" + Net.enc(it.groupValues[1])) }
        Regex("^(?:youtube|yt)\\s+(?:pe\\s+|par\\s+)?(.+)$").find(l)?.let { return Cmd("youtube", it.groupValues[1]) }
        Regex("^play\\s+(.+?)(?:\\s+on\\s+youtube)?$").find(l)?.let { return Cmd("youtube", it.groupValues[1]) }
        Regex("^(?:search|google)\\s+(?:for\\s+)?(.+)$").find(l)?.let { return Cmd("search", it.groupValues[1]) }
        if (words <= 8) {
            Regex("^(.+?)\\s+(?:search|google)\\s*$DO?$").find(l)?.let { return Cmd("search", it.groupValues[1]) }
        }
        return null
    }

    private fun cleanCallName(n: String): String =
        n.replace(Regex("\\s+(?:ko|ko\\s+)?(?:call|phone|laga|lagao|$DO)$"), "").trim()
}
