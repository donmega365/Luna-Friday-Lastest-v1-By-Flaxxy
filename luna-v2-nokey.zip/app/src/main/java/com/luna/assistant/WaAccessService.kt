package com.luna.assistant

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

// Only watches WhatsApp / WhatsApp Business windows, and only while the app has a pending
// "send this message" request that is less than 25 seconds old.
class WaAccessService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private val sendWords = listOf("send", "भेजें", "भेजे", "ارسال", "بھیجیں", "enviar", "envoyer", "senden", "kirim")

    override fun onServiceConnected() {
        super.onServiceConnected()
        AppLog.add(this, "WhatsApp auto-send service connected")
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val p = WaSender.pending ?: return
        if (System.currentTimeMillis() > p.expires) {
            WaSender.pending = null
            AppLog.add(this, "WhatsApp auto-send timed out (Send button not found)")
            return
        }
        val pkg = e?.packageName?.toString() ?: return
        if (pkg != "com.whatsapp" && pkg != "com.whatsapp.w4b") return
        val root = rootInActiveWindow ?: return
        var node: AccessibilityNodeInfo? = root.findAccessibilityNodeInfosByViewId(pkg + ":id/send")?.firstOrNull()
        if (node != null && isVoice(node)) node = null
        if (node == null) node = findByDesc(root, 0)
        if (node != null && clickUp(node)) {
            WaSender.pending = null
            AppLog.add(this, "WhatsApp message sent")
            h.post { Toast.makeText(applicationContext, "WhatsApp message sent", Toast.LENGTH_SHORT).show() }
            if (Prefs.getBool(this, "wa_back", true)) {
                h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 700)
                h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 1300)
            }
        }
    }

    private fun isVoice(n: AccessibilityNodeInfo): Boolean {
        val d = n.contentDescription?.toString()?.lowercase() ?: return false
        return d.contains("voice") || d.contains("record") || d.contains("mic")
    }

    private fun findByDesc(n: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 12) return null
        val d = n.contentDescription?.toString()?.trim()?.lowercase()
        if (d != null && d in sendWords) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val r = findByDesc(c, depth + 1)
            if (r != null) return r
        }
        return null
    }

    private fun clickUp(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        var depth = 0
        while (x != null && depth < 4) {
            if (x.isClickable && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            x = x.parent
            depth++
        }
        return false
    }
}
