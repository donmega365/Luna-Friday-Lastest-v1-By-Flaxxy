package com.luna.assistant

import android.content.Context

// Assistant replies in English (default), Hindi, Urdu. Other languages fall back to English.
object L {
    private val T: Map<String, List<String>> = mapOf(
        "greet" to listOf(
            "Hi, I'm %s. I can open apps, call and message your contacts, set alarms, check the weather and news, and answer questions. Try \"call Rahul\", \"weather\" or \"alarm 7:30\".",
            "नमस्ते! मैं %s हूँ। बोलिए: 'open whatsapp', 'call Rahul', 'torch on', 'busy on' या कुछ भी पूछिए।",
            "السلام علیکم! میں %s ہوں۔ بولیں: 'open whatsapp', 'call Rahul', 'torch on', 'busy on' یا کچھ بھی پوچھیں۔"
        ),
        "offline" to listOf(
            "I'm offline right now Commands still work (open, call, sms, torch, volume, alarm...). AI chat needs internet.",
            "अभी ऑफ़लाइन हूँ कमांड्स काम करेंगे (open, call, sms, torch, volume, alarm...)। AI चैट के लिए इंटरनेट चाहिए।",
            "ابھی آف لائن ہوں کمانڈز کام کریں گی (open, call, sms, torch, volume, alarm...)۔ AI چیٹ کے لیے انٹرنیٹ چاہیے۔"
        ),
        "cancelled" to listOf("Okay, cancelled.", "ठीक है, रद्द कर दिया।", "ٹھیک ہے، منسوخ کر دیا۔"),
        "q_open" to listOf("Open %s?", "%s खोलूँ?", "%s کھولوں؟"),
        "q_torch" to listOf("Turn torch %s?", "टॉर्च %s करूँ?", "ٹارچ %s کروں؟"),
        "q_call" to listOf("Call %s?", "%s को कॉल करूँ?", "%s کو کال کروں؟"),
        "q_sms" to listOf("Send SMS to %s: \"%s\"?", "%s को SMS भेजूँ: \"%s\"?", "%s کو SMS بھیجوں: \"%s\"؟"),
        "q_busy" to listOf("Turn busy mode %s?", "बिज़ी मोड %s करूँ?", "بزی موڈ %s کروں؟"),
        "q_wamsg" to listOf(
            "Send WhatsApp to %s: \"%s\"?",
            "%s को WhatsApp भेजूँ: \"%s\"?",
            "%s کو WhatsApp بھیجوں: \"%s\"؟"
        ),
        "wa_sending" to listOf(
            "Sending WhatsApp message to %s...",
            "%s को WhatsApp मैसेज भेज रहा हूँ...",
            "%s کو WhatsApp میسج بھیج رہا ہوں..."
        ),
        "wa_missing" to listOf("WhatsApp isn't installed.", "WhatsApp इंस्टॉल नहीं है।", "WhatsApp انسٹال نہیں ہے۔"),
        "q_readsms" to listOf("Read your last SMS?", "आपका आख़िरी SMS पढ़ूँ?", "آپ کا آخری SMS پڑھوں؟"),
        "q_generic" to listOf("Do it?", "करूँ?", "کروں؟"),
        "opening" to listOf("Opening %s", "%s खोल रहा हूँ", "%s کھول رہا ہوں"),
        "app_nf" to listOf(
            "I couldn't find an app called '%s'.",
            "'%s' नाम का ऐप नहीं मिला।",
            "'%s' نام کی ایپ نہیں ملی۔"
        ),
        "torch_done" to listOf("Torch %s", "टॉर्च %s", "ٹارچ %s"),
        "calling" to listOf("Calling %s", "%s को कॉल कर रहा हूँ", "%s کو کال کر رہا ہوں"),
        "num_nf" to listOf(
            "I couldn't find a number for '%s'. Check the Contacts permission.",
            "'%s' का नंबर नहीं मिला। Contacts permission जाँचें।",
            "'%s' کا نمبر نہیں ملا۔ Contacts permission چیک کریں۔"
        ),
        "sms_ok" to listOf("SMS sent", "SMS भेज दिया", "SMS بھیج دیا"),
        "sms_fail" to listOf(
            "I couldn't send the SMS (missing number or SMS permission).",
            "SMS नहीं भेज सका (नंबर या SMS permission नहीं है)।",
            "SMS نہیں بھیج سکا (نمبر یا SMS permission نہیں ہے)۔"
        ),
        "busy_set" to listOf("Busy mode %s", "बिज़ी मोड %s", "بزی موڈ %s"),
        "vol_ok" to listOf("Volume updated", "वॉल्यूम बदल दिया", "والیوم تبدیل کر دیا"),
        "bright_ok" to listOf("Brightness set to %s%%", "ब्राइटनेस %s%%", "برائٹنس %s%%"),
        "need_write" to listOf(
            "Please allow 'Modify system settings' for me first.",
            "पहले 'Modify system settings' की अनुमति दें।",
            "پہلے 'Modify system settings' کی اجازت دیں۔"
        ),
        "alarm_ok" to listOf("Alarm set for %s", "%s का अलार्म लगा दिया", "%s کا الارم لگا دیا"),
        "timer_ok" to listOf("Timer started", "टाइमर शुरू", "ٹائمر شروع"),
        "battery" to listOf("Battery is at %s%%", "बैटरी %s%% है", "بیٹری %s%% ہے"),
        "time_now" to listOf("It's %s", "अभी %s है", "اس وقت %s ہے"),
        "sms_last" to listOf("Last SMS from %s: %s", "%s का आख़िरी SMS: %s", "%s کا آخری SMS: %s"),
        "sms_none" to listOf(
            "I couldn't read any SMS (permission missing or inbox empty).",
            "कोई SMS नहीं पढ़ सका (permission नहीं या इनबॉक्स ख़ाली)।",
            "کوئی SMS نہیں پڑھ سکا (permission نہیں یا ان باکس خالی)۔"
        ),
        "searching" to listOf("Searching for %s", "%s खोज रहा हूँ", "%s تلاش کر رہا ہوں"),
        "navigating" to listOf("Navigating to %s", "%s के लिए रास्ता खोल रहा हूँ", "%s کے لیے راستہ کھول رہا ہوں"),
        "wa_open" to listOf(
            "Opening WhatsApp chat with %s. Tap send.",
            "%s के साथ WhatsApp चैट खोल रहा हूँ। send दबाएँ।",
            "%s کے ساتھ WhatsApp چیٹ کھول رہا ہوں۔ send دبائیں۔"
        ),
        "listening" to listOf("Listening...", "सुन रहा हूँ...", "سن رہا ہوں..."),
        "not_heard" to listOf("I couldn't catch that (code %s).", "समझ नहीं आया (code %s)।", "سمجھ نہیں آیا (code %s)۔"),
        "ask_msg" to listOf("What should I send to %s?", "%s को क्या भेजूँ?", "%s کو کیا بھیجوں؟"),
        "who" to listOf("Who is \"%s\"? Pick the right contact and I'll remember it.", "\"%s\" कौन है? सही कॉन्टैक्ट चुनें, मैं याद रखूँगा।", "\"%s\" کون ہے؟ صحیح کانٹیکٹ چنیں، میں یاد رکھوں گا۔"),
        "which_num" to listOf("Which number for %s?", "%s का कौन सा नंबर?", "%s کا کون سا نمبر؟"),
        "learned_alias" to listOf("Got it. \"%s\" means %s from now on.", "ठीक है, अब \"%s\" मतलब %s।", "ٹھیک ہے، اب \"%s\" یعنی %s۔"),
        "learned_num" to listOf("Saved %s: %s", "%s का नंबर सेव किया: %s", "%s کا نمبر محفوظ کر لیا: %s"),
        "num_is" to listOf("%s: %s", "%s: %s", "%s: %s"),
        "forgot" to listOf("Forgotten.", "भूल गया।", "بھول گیا۔"),
        "forgot_none" to listOf("I don't have anything saved under that name.", "इस नाम से कुछ सेव नहीं है।", "اس نام سے کچھ محفوظ نہیں ہے۔"),
        "need_contacts" to listOf("I need the Contacts permission to find names. Turn it on in the Access tab, or tell me the number directly.", "नाम खोजने के लिए Contacts permission चाहिए। Access टैब में चालू करें।", "نام تلاش کرنے کے لیے Contacts permission چاہیے۔ Access ٹیب میں آن کریں۔"),
        "working" to listOf("Checking %s...", "%s देख रहा हूँ...", "%s دیکھ رہا ہوں..."),
        "url_open" to listOf("Opening %s", "%s खोल रहा हूँ", "%s کھول رہا ہوں"),
        "url_fail" to listOf("No app on this phone can open that link.", "इस लिंक को खोलने वाला कोई ऐप नहीं है।", "اس لنک کو کھولنے والی کوئی ایپ نہیں ہے۔"),
        "url_bad" to listOf("I can't open that kind of link.", "मैं इस तरह का लिंक नहीं खोल सकता।", "میں اس قسم کا لنک نہیں کھول سکتا۔"),
        "q_connector" to listOf("Run connector \"%s\"?", "कनेक्टर \"%s\" चलाऊँ?", "کنیکٹر \"%s\" چلاؤں؟"),
        "too_deep" to listOf("I couldn't finish that. Please try again.", "यह पूरा नहीं हो सका। दोबारा कोशिश करें।", "یہ مکمل نہیں ہو سکا۔ دوبارہ کوشش کریں۔"),
        "cancel_word" to listOf("cancel", "cancel", "cancel"),
        "error" to listOf("Something went wrong: %s", "कुछ गड़बड़ हुई: %s", "کچھ گڑبڑ ہوئی: %s")
    )

    fun code(tag: String) = tag.substringBefore("-").lowercase()

    // Language of a user message: by script (Hindi / Urdu), else the language chosen in Settings.
    fun detect(c: Context, text: String): String {
        for (ch in text) {
            val cp = ch.code
            if (cp in 0x0900..0x097F) return "hi"
            if (cp in 0x0600..0x06FF) return "ur"
        }
        return code(Prefs.get(c, "lang", "en-US"))
    }

    fun t(lang: String, key: String, vararg a: Any): String {
        val l = T[key] ?: return key
        val i = when (lang) {
            "hi" -> 1
            "ur" -> 2
            else -> 0
        }
        val s = l.getOrNull(i)?.takeIf { it.isNotBlank() } ?: l[0]
        return if (a.isEmpty()) s else String.format(s, *a)
    }
}
