package com.luna.assistant

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

fun EditText.onChange(f: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) {
            f(s?.toString() ?: "")
        }
    })
}

// a text field that saves itself into preferences as you type
fun MainActivity.prefEdit(hint: String, key: String, def: String = "", lines: Int = 1, secret: Boolean = false): EditText {
    val e = edit(hint, Prefs.get(this, key, def), lines)
    if (secret) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    val ctx = this
    e.onChange { Prefs.put(ctx, key, if (lines > 1) it else it.trim()) }
    return e
}

fun MainActivity.requestAll(perms: List<String>) {
    permQueue.clear()
    perms.forEach { permQueue.add(it) }
    nextPerm()
}

fun MainActivity.pickContacts(onDone: (List<String>) -> Unit) {
    if (!Contacts.ok(this)) {
        toast("Allow the Contacts permission first.")
        requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 12)
        return
    }
    val all = Contacts.all(this).map { it.name }.distinct().sortedBy { it.lowercase() }
    val chosen = LinkedHashSet<String>(Prefs.getList(this, "busy_friends"))
    var shown: List<String> = all
    val ctx = this
    val adapter = object : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val n = shown[position]
            val on = chosen.contains(n)
            val t = ctx.tv((if (on) "\u2713   " else "      ") + n, 15f, if (on) Pal.accent else Pal.text, if (on) 1 else 0)
            t.setPadding(ctx.dp(18), ctx.dp(12), ctx.dp(18), ctx.dp(12))
            return t
        }
    }
    val lv = ListView(this)
    lv.adapter = adapter
    lv.divider = null
    lv.setOnItemClickListener { _, _, pos, _ ->
        val n = shown[pos]
        if (!chosen.add(n)) chosen.remove(n)
        adapter.notifyDataSetChanged()
    }
    val search = edit("Search contacts", "")
    search.onChange { q ->
        shown = if (q.isBlank()) all else all.filter { it.contains(q, true) || Names.score(q, it) >= 55 }
        adapter.notifyDataSetChanged()
    }
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(16), dp(8), dp(16), 0)
    box.addView(search, lp(0, 8))
    box.addView(lv, LinearLayout.LayoutParams(-1, dp(340)))
    val b = AlertDialog.Builder(this)
        .setTitle("Choose friends")
        .setView(box)
        .setPositiveButton("Done") { _, _ -> onDone(chosen.toList()) }
        .setNegativeButton("Cancel", null)
    showDialog(b)
}

// ---------------------------------------------------------------- BUSY
fun MainActivity.busyView(): View {
    val a = this
    val v = ArrayList<View>()
    v.add(heading("Busy mode", "Luna replies for you while you're away. Pick who gets the reply."))

    val friends = Prefs.getList(a, "busy_friends")
    val on = Prefs.getBool(a, "busy")

    val hero = card()
    val hr = LinearLayout(a)
    hr.orientation = LinearLayout.HORIZONTAL
    hr.gravity = Gravity.CENTER_VERTICAL
    val hc = LinearLayout(a)
    hc.orientation = LinearLayout.VERTICAL
    hc.addView(tv(if (on) "Busy mode is on" else "Busy mode is off", 17f, Pal.text, 1))
    val subText = if (friends.isEmpty()) "Add friends below to get started" else "Replying to " + friends.size + (if (friends.size == 1) " person" else " people")
    val hs = tv(subText, 13f, Pal.sub)
    hs.setPadding(0, dp(3), 0, 0)
    hc.addView(hs)
    hr.addView(hc, LinearLayout.LayoutParams(0, -2, 1f))
    hr.addView(sw(on) {
        Prefs.putBool(a, "busy", it)
        show(1)
    })
    hero.addView(hr)
    v.add(hero)

    // ----- setup checklist -----
    val pw = getSystemService(PowerManager::class.java)
    class Step(val label: String, val ok: Boolean, val fix: () -> Unit)
    val steps = listOf(
        Step("Notification access", listenerOn()) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
        Step("Contacts permission", granted(Manifest.permission.READ_CONTACTS)) { requestAll(listOf(Manifest.permission.READ_CONTACTS)) },
        Step(
            "Call permissions",
            granted(Manifest.permission.READ_PHONE_STATE) && granted(Manifest.permission.READ_CALL_LOG) && granted(Manifest.permission.ANSWER_PHONE_CALLS)
        ) {
            requestAll(listOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS))
        },
        Step("SMS permission", granted(Manifest.permission.SEND_SMS)) { requestAll(listOf(Manifest.permission.SEND_SMS)) },
        Step("WhatsApp auto-send", WaSender.accessibilityOn(a)) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
        Step("Display over other apps", Settings.canDrawOverlays(a)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        },
        Step("Battery unrestricted", pw.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    )
    val ready = steps.count { it.ok }
    v.add(label("Setup  \u00B7  $ready of ${steps.size} ready"))
    v.add(group(steps.map { s ->
        val t = tv(if (s.ok) "Ready" else "Fix", 13f, if (s.ok) Pal.good else Pal.warn, 1)
        if (s.ok) settingRow(s.label, "", t) else settingRow(s.label, "", t) { s.fix() }
    }))

    // ----- message -----
    v.add(label("Auto-reply message"))
    val mc = card()
    val msg = prefEdit("What should Luna say?", "busy_msg", Defaults.MSG, 3)
    mc.addView(msg, lp(0, 10))
    val tf = FlowLayout(a)
    tf.hGap = dp(8)
    tf.vGap = dp(8)
    listOf(
        "I'm out right now and will be back in 5-10 minutes.",
        "In a meeting, I'll reply soon.",
        "Driving at the moment, will call you back.",
        "Main abhi bahar hu, 5-10 min me wapas aata hu."
    ).forEach { t ->
        tf.addView(chip(t.take(26).trim() + (if (t.length > 26) "..." else "")) { msg.setText(t) })
    }
    mc.addView(tf)
    v.add(mc)

    // ----- friends -----
    v.add(label("Friends"))
    val fc = card()
    if (friends.isEmpty()) {
        fc.addView(tv("Nobody yet. Luna only replies to the people listed here.", 13.5f, Pal.sub), lp(0, 10))
    } else {
        val ff = FlowLayout(a)
        ff.hGap = dp(8)
        ff.vGap = dp(8)
        friends.forEach { f ->
            val ch = tv("$f   \u00D7", 14f, Pal.text)
            ch.setPadding(dp(14), dp(8), dp(12), dp(8))
            ch.background = ripple(rr(Pal.alpha(Pal.accent, 0.14f), 18), 18)
            ch.isClickable = true
            ch.setOnClickListener {
                val l = Prefs.getList(a, "busy_friends")
                l.remove(f)
                Prefs.putList(a, "busy_friends", l)
                show(1)
            }
            ff.addView(ch)
        }
        fc.addView(ff, lp(0, 12))
    }
    val fb = LinearLayout(a)
    fb.orientation = LinearLayout.HORIZONTAL
    fb.addView(btn("From contacts", 1, R.drawable.ic_user) {
        pickContacts { chosen ->
            Prefs.putList(a, "busy_friends", chosen)
            show(1)
        }
    }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
    fb.addView(btn("Type a name", 1, R.drawable.ic_plus) {
        val e = edit("Name, nickname or number", "")
        val box = LinearLayout(a)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(e, LinearLayout.LayoutParams(-1, -2))
        val b = AlertDialog.Builder(a).setTitle("Add a friend").setView(box)
            .setPositiveButton("Add") { _, _ ->
                val t = e.text.toString().trim()
                if (t.isNotEmpty()) {
                    val l = Prefs.getList(a, "busy_friends")
                    if (l.none { it.equals(t, true) }) l.add(t)
                    Prefs.putList(a, "busy_friends", l)
                    show(1)
                }
            }
            .setNegativeButton("Cancel", null)
        showDialog(b)
    }, LinearLayout.LayoutParams(0, -2, 1f))
    fc.addView(fb)
    val note = tv("Matches saved names, nicknames and numbers. Group chats are skipped.", 12f, Pal.sub)
    note.setPadding(0, dp(10), 0, 0)
    fc.addView(note)
    v.add(fc)

    // ----- how often -----
    v.add(label("Repeat replies"))
    val cools = listOf(5, 10, 30, 60)
    val curCool = Prefs.get(a, "cooldown", "10").toIntOrNull() ?: 10
    v.add(segmented(cools.map { if (it < 60) "$it min" else "1 hour" }, cools.indexOf(curCool).coerceAtLeast(0)) {
        Prefs.put(a, "cooldown", cools[it].toString())
        show(1)
    })
    val cn = tv("Luna won't reply to the same person again within this time.", 12f, Pal.sub)
    cn.setPadding(dp(4), 0, 0, 0)
    v.add(cn)

    // ----- calls -----
    v.add(label("When a friend calls"))
    val cur = Prefs.get(a, "call_action", "sms")
    fun opt(id: String, t: String, s: String): View {
        val tick = if (cur == id) ic(R.drawable.ic_check, 20, Pal.accent) else View(a)
        return settingRow(t, s, tick) {
            Prefs.put(a, "call_action", id)
            show(1)
        }
    }
    v.add(
        group(
            listOf(
                opt("sms", "Reject and send an SMS", "Works without WhatsApp"),
                opt("wa", "Reject and send a WhatsApp message", "Needs WhatsApp auto-send"),
                opt("answer", "Answer and speak the message", "The caller may hear it on speaker")
            )
        )
    )
    v.add(prefEdit("Message for callers (optional)", "call_msg"))

    // ----- test + log -----
    v.add(btn("Run a test reply", 1) {
        SelfTest.run(a)
        toast("Test started. Check the log in a few seconds.")
        handler.postDelayed({ if (current == 1) show(1) }, 4000)
    })
    v.add(label("Activity log"))
    val lc = card()
    val lt = tv(AppLog.text(a), 12f, Pal.sub)
    lt.setTextIsSelectable(true)
    lc.addView(lt, lp(0, 10))
    val lr = LinearLayout(a)
    lr.addView(btn("Refresh", 1) { show(1) }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
    lr.addView(btn("Clear", 1) {
        AppLog.clear(a)
        show(1)
    }, LinearLayout.LayoutParams(0, -2, 1f))
    lc.addView(lr)
    v.add(lc)
    return page(v)
}

// ---------------------------------------------------------------- CONNECT
fun MainActivity.editConnector(existing: Connectors.Custom?) {
    val a = this
    val name = edit("Name, e.g. Lights", existing?.name ?: "")
    val desc = edit("When should Luna use it?", existing?.desc ?: "", 2)
    var method = existing?.method ?: "POST"
    val url = edit("URL", existing?.url ?: "https://")
    val headers = edit("Headers, one per line (Key: Value)", existing?.headers ?: "", 2)
    val body = edit("Body (use {input} for the text)", existing?.body ?: "{\"input\": \"{input}\"}", 3)
    val methodRow = LinearLayout(a)
    val mg = tv(if (method == "GET") "Method: GET  (tap to switch)" else "Method: POST  (tap to switch)", 13.5f, Pal.accent, 1)
    mg.setPadding(dp(4), dp(8), dp(4), dp(8))
    mg.setOnClickListener {
        method = if (method == "GET") "POST" else "GET"
        mg.text = if (method == "GET") "Method: GET  (tap to switch)" else "Method: POST  (tap to switch)"
    }
    methodRow.addView(mg)

    val box = LinearLayout(a)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(dp(20), dp(8), dp(20), 0)
    if (existing == null) {
        box.addView(tv("Start from a template", 12f, Pal.sub), lp(0, 6))
        val pf = FlowLayout(a)
        pf.hGap = dp(6)
        pf.vGap = dp(6)
        Connectors.presets.forEach { p ->
            pf.addView(chip(p.title) {
                if (name.text.isNullOrBlank()) name.setText(p.title.substringBefore(" ").ifBlank { p.title })
                desc.setText(p.desc)
                method = p.method
                mg.text = if (method == "GET") "Method: GET  (tap to switch)" else "Method: POST  (tap to switch)"
                url.setText(p.url)
                headers.setText(p.headers)
                body.setText(p.body)
            })
        }
        box.addView(pf, lp(0, 10))
    }
    box.addView(name, lp(0, 8))
    box.addView(desc, lp(0, 8))
    box.addView(methodRow, lp(0, 4))
    box.addView(url, lp(0, 8))
    box.addView(headers, lp(0, 8))
    box.addView(body, lp(0, 8))
    val hint = tv("Replace anything in <ANGLE BRACKETS> with your own values. Luna only calls it when a request fits the description.", 12f, Pal.sub)
    box.addView(hint, lp(0, 8))
    val sv = android.widget.ScrollView(a)
    sv.addView(box)

    val b = AlertDialog.Builder(a)
        .setTitle(if (existing == null) "New connector" else "Edit connector")
        .setView(sv)
        .setPositiveButton("Save") { _, _ ->
            val n = name.text.toString().replace("\"", "").replace("\\", "").trim()
            val u = url.text.toString().trim()
            if (n.isEmpty() || !u.startsWith("http")) {
                toast("A name and a full URL (http or https) are needed.")
            } else {
                val list = Connectors.customList(a)
                val item = if (existing != null) list.firstOrNull { it.id == existing.id } else null
                if (item != null) {
                    item.name = n
                    item.desc = desc.text.toString().replace("\"", "'").trim()
                    item.method = method
                    item.url = u
                    item.headers = headers.text.toString().trim()
                    item.body = body.text.toString().trim()
                } else {
                    list.add(Connectors.Custom(System.currentTimeMillis().toString(), n, desc.text.toString().replace("\"", "'").trim(), method, u, headers.text.toString().trim(), body.text.toString().trim(), true))
                }
                Connectors.saveCustom(a, list)
                show(2)
            }
        }
        .setNegativeButton("Cancel", null)
    if (existing != null) {
        b.setNeutralButton("Delete") { _, _ ->
            val list = Connectors.customList(a)
            list.removeAll { it.id == existing.id }
            Connectors.saveCustom(a, list)
            show(2)
        }
    }
    showDialog(b)
}

fun MainActivity.connectView(): View {
    val a = this
    val v = ArrayList<View>()
    v.add(heading("Connect", "Give Luna access to the web and to your own services and apps."))

    v.add(label("Built-in"))
    v.add(group(Connectors.builtins.map { c ->
        settingRow(c.title, c.sub, sw(Connectors.builtinOn(a, c.id)) { Connectors.setBuiltin(a, c.id, it) }, c.icon)
    }))

    v.add(label("Defaults"))
    val dc = card()
    dc.addView(prefEdit("Home city (for weather)", "home_city"), lp(0, 8))
    dc.addView(prefEdit("Brave Search API key (optional, better web search)", "key_brave", "", 1, true), lp(0, 0))
    v.add(dc)

    v.add(btn("Test connections", 1, R.drawable.ic_refresh) {
        toast("Testing...")
        Thread {
            val lines = ArrayList<String>()
            lines.add("Weather: " + Tools.run(a, Cmd("weather", "London")).lines().first().take(90))
            lines.add("News: " + Tools.run(a, Cmd("news", "")).lines().take(2).joinToString(" ").take(90))
            lines.add("Facts: " + Tools.run(a, Cmd("lookup", "Moon")).take(90))
            lines.add("Currency: " + Tools.run(a, Cmd("fx", "1", "USD", "EUR")).take(90))
            runOnUiThread {
                showDialog(AlertDialog.Builder(a).setTitle("Connection test").setMessage(lines.joinToString("\n\n")).setPositiveButton("OK", null))
            }
        }.start()
    })

    v.add(label("Your connectors"))
    val custom = Connectors.customList(a)
    if (custom.isEmpty()) {
        v.add(
            tv(
                "Add webhooks and APIs (Telegram, IFTTT, Home Assistant, Discord, Slack, your own server) and Luna can use them when you ask, e.g. \"turn off the lights\".",
                13f, Pal.sub
            )
        )
    } else {
        v.add(group(custom.map { cn ->
            settingRow(cn.name, cn.desc.ifBlank { cn.method + " " + cn.url.take(40) }, sw(cn.enabled) {
                val l = Connectors.customList(a)
                l.firstOrNull { x -> x.id == cn.id }?.enabled = it
                Connectors.saveCustom(a, l)
            }, R.drawable.ic_webhook) { editConnector(cn) }
        }))
    }
    v.add(btn("Add a connector", 0, R.drawable.ic_plus) { editConnector(null) })
    return page(v)
}
